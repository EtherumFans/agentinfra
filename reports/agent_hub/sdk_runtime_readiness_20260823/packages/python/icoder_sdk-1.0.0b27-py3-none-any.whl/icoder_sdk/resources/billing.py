"""Billing & Usage resources."""

from ..client import iCoDerClient
from ..types import UsageSummary


class BillingResource:
    def __init__(self, client: iCoDerClient):
        self._client = client

    def balance(self) -> dict:
        resp = self._client.get("/api/billing/balance")
        resp.raise_for_status()
        return resp.json()

    def transactions(self, page: int = 1, page_size: int = 20) -> dict:
        resp = self._client.get("/api/billing/transactions", params={"page": page, "page_size": page_size})
        resp.raise_for_status()
        return resp.json()

    def simulate_debit(self, amount: float, reference: str) -> dict:
        """Debit the local development ledger; cloud mode rejects this call."""
        resp = self._client.post(
            "/api/billing/simulation/debit",
            json={"amount": amount, "reference": reference},
        )
        resp.raise_for_status()
        return resp.json()

    def run_settlements(self, limit: int = 20) -> dict:
        """List PHI-free local Agent Run preauthorization settlements."""
        resp = self._client.get(
            "/api/billing/run-settlements", params={"limit": limit},
        )
        resp.raise_for_status()
        return resp.json()

    def retry_run_settlement(self, run_id: str) -> dict:
        """Retry a failed local settlement after adding credits."""
        from urllib.parse import quote

        resp = self._client.post(
            f"/api/billing/run-settlements/{quote(run_id, safe='')}/retry"
        )
        resp.raise_for_status()
        return resp.json()

    def reconcile_stale_run_settlements(self, older_than_seconds: int = 3600) -> dict:
        """Reconcile old crash-orphaned reservations; active runs are skipped."""
        resp = self._client.post(
            "/api/billing/run-settlements/reconcile-stale",
            params={"older_than_seconds": older_than_seconds},
        )
        resp.raise_for_status()
        return resp.json()


class UsageResource:
    def __init__(self, client: iCoDerClient):
        self._client = client

    def summary(self, days: int = 30) -> UsageSummary:
        resp = self._client.get("/api/usage/summary", params={"days": days})
        resp.raise_for_status()
        data = resp.json()
        return UsageSummary(
            total_requests=data.get("total_requests", 0),
            credits_used=data.get("credits_used", 0),
            avg_response_time_ms=data.get("avg_response_time_ms", 0),
        )

    def history(self, days: int = 30) -> dict:
        resp = self._client.get("/api/usage/history", params={"days": days})
        resp.raise_for_status()
        return resp.json()
