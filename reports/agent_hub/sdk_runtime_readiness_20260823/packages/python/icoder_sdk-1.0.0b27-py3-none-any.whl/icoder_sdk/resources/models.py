"""Secret-free model configuration and regional egress readiness."""

from __future__ import annotations

from typing import Literal, TypedDict, cast

from ..client import iCoDerClient


class ModelCatalogItem(TypedDict):
    id: str
    display_name: str
    default_model: str
    model: str
    deployment_kind: str
    selected: bool
    credential_required: bool
    credential_configured: bool | None
    adapter_capabilities: list[str]
    china_scenario: str
    provider_region: Literal["cn", "eu", "us"]
    tenant_region: Literal["cn", "eu", "us"]
    egress_decision: Literal["allow", "deny"]
    status: Literal[
        "available_to_configure",
        "configured_not_live_verified",
        "development_only",
        "blocked",
    ]
    blocking_reasons: list[str]
    health_status: str
    health_checked_at: str | None
    canary_status: str
    canary_checked_at: str | None
    canary_scope: Literal["connectivity_only_no_patient_data"]


class ModelLiveCanaryPolicy(TypedDict):
    purpose: Literal["connectivity_only_no_patient_data"]
    fixed_synthetic_payload: Literal[True]
    patient_data_allowed: Literal[False]
    requires_owner_admin: Literal[True]
    requires_explicit_acknowledgement: Literal[True]
    max_cost_cny: float
    max_output_tokens: int
    timeout_seconds: float
    cooldown_seconds: int


class ModelCatalog(TypedDict):
    active_provider: str
    active_model: str
    operator_default_provider: str
    operator_default_model: str
    effective_deployment_id: str
    tenant_selection: "TenantModelSelection"
    registered_deployments: list["ModelDeployment"]
    selection_editable: bool
    live_canary_available: bool
    live_canary_policy: ModelLiveCanaryPolicy
    tenant_region: Literal["cn", "eu", "us"]
    egress_policy: Literal["strict", "best_effort", "off"]
    external_llm_allowed: bool
    models: list[ModelCatalogItem]
    readiness_scope: Literal["configuration_and_policy_only"]
    live_health_verified: Literal[False]
    disclaimer: str


class TenantModelSelection(TypedDict):
    mode: Literal["inherit", "pinned"]
    deployment_id: str | None
    version: int


class ModelDeployment(TypedDict):
    id: str
    provider_id: str
    model: str
    is_default: bool
    tenant_selectable: bool
    credential_configured: bool
    canary_status: str
    canary_checked_at: str | None


class ModelHealthProbe(TypedDict):
    deployment_id: str
    provider_id: str
    model: str
    status: str
    probe_mode: Literal["configuration"]
    egress_decision: Literal["allow", "deny"]
    credential_configured: bool
    circuit_open: bool
    checked_at: str


class ModelLiveCanaryUsage(TypedDict):
    input_tokens: int
    output_tokens: int


class ModelLiveCanaryCost(TypedDict):
    amount: float
    currency: Literal["CNY"]
    billing_authoritative: Literal[False]
    source: Literal["provider_usage_pricing_estimate"]


class ModelLiveCanaryResponse(TypedDict):
    deployment_id: str
    provider_id: str
    model: str
    status: Literal[
        "reachable", "provider_unavailable", "unexpected_response", "budget_exceeded"
    ]
    reason_code: Literal[
        "ok",
        "provider_degraded",
        "provider_timeout",
        "provider_exception",
        "unexpected_response",
        "reported_cost_exceeded_cap",
    ]
    probe_mode: Literal["external_connectivity_canary"]
    egress_decision: Literal["allow"]
    synthetic_payload: Literal[True]
    patient_data_sent: Literal[False]
    expected_token_matched: bool
    latency_ms: int
    usage: ModelLiveCanaryUsage
    cost: ModelLiveCanaryCost
    request_cost_cap_cny: float
    estimated_max_cost_cny: float
    checked_at: str


class ModelsResource:
    def __init__(self, client: iCoDerClient):
        self._client = client

    def get_catalog(self) -> ModelCatalog:
        response = self._client.get("/api/v1/model-catalog")
        response.raise_for_status()
        return cast(ModelCatalog, response.json())

    def update_selection(
        self,
        *,
        mode: Literal["inherit", "pinned"],
        expected_version: int,
        deployment_id: str | None = None,
    ) -> TenantModelSelection:
        payload: dict[str, object] = {
            "mode": mode,
            "expected_version": expected_version,
        }
        if deployment_id is not None:
            payload["deployment_id"] = deployment_id
        response = self._client.put(
            "/api/v1/model-catalog/selection",
            json=payload,
        )
        response.raise_for_status()
        return cast(TenantModelSelection, response.json())

    def health_probe(self, deployment_id: str) -> ModelHealthProbe:
        """Run a no-network, configuration-only deployment health probe."""
        response = self._client.post(
            "/api/v1/model-catalog/health-probe",
            json={"deployment_id": deployment_id},
        )
        response.raise_for_status()
        return cast(ModelHealthProbe, response.json())

    def live_canary(
        self,
        deployment_id: str,
        *,
        max_cost_cny: float,
    ) -> ModelLiveCanaryResponse:
        """Run one fixed-payload, explicitly acknowledged external call."""
        if not isinstance(deployment_id, str) or not deployment_id.strip() or len(deployment_id) > 64:
            raise ValueError("deployment_id must contain between 1 and 64 characters")
        if (
            isinstance(max_cost_cny, bool)
            or not isinstance(max_cost_cny, (int, float))
            or max_cost_cny <= 0
            or max_cost_cny > 1
        ):
            raise ValueError("max_cost_cny must be greater than 0 and at most 1")
        response = self._client.post(
            "/api/v1/model-catalog/live-canary",
            json={
                "deployment_id": deployment_id,
                "acknowledge_external_call": True,
                "purpose": "connectivity_only_no_patient_data",
                "max_cost_cny": float(max_cost_cny),
            },
        )
        response.raise_for_status()
        return cast(ModelLiveCanaryResponse, response.json())
