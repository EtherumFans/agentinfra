"""Type definitions for iCoDer Python SDK."""

from __future__ import annotations
from typing import Optional, Any, Generic, Literal, TypeVar, TypedDict, cast
from dataclasses import dataclass, field


class AgentHubRuntimeReadiness(TypedDict):
    structural_status: Literal["ready", "blocked"]
    configuration_status: Literal[
        "not_checked",
        "local_ready",
        "configured_not_live_verified",
        "unavailable",
    ]
    run_action_enabled: bool
    reason: str
    runtime_dependencies: list[str]
    external_llm_required: bool
    live_health_verified: bool
    semantic_validation_status: Literal["verified", "not_verified"]
    production_approval_status: Literal["approved", "not_approved"]


class AgentHubCard(TypedDict):
    agent_id: str
    agent_ref: str
    name: str
    execution_path: str
    execution_target: str
    runtime_readiness: AgentHubRuntimeReadiness
    output_contract: dict[str, Any]


class AgentHubResponse(TypedDict):
    agents: list[AgentHubCard]
    total: int
    source: str
    schema_version: Literal["1.3"]


class A2ALegacyAgentCard(TypedDict):
    name: str
    description: str
    url: str
    version: str
    provider: str
    capabilities: dict[str, Any]
    skills: list[dict[str, Any]]
    defaultInputModes: list[str]
    defaultOutputModes: list[str]
    securitySchemes: dict[str, Any]


def validate_agent_hub_response(value: Any) -> AgentHubResponse:
    """Fail closed on malformed current Hub readiness instead of guessing."""
    if not isinstance(value, dict) or value.get("schema_version") != "1.3":
        raise ValueError(
            "Unsupported or malformed Agent Hub response; schema_version 1.3 is required."
        )
    cards = value.get("agents")
    if not isinstance(cards, list):
        raise ValueError("Agent Hub schema 1.3 response is missing agents.")
    configuration_statuses = {
        "not_checked",
        "local_ready",
        "configured_not_live_verified",
        "unavailable",
    }
    for card in cards:
        readiness = card.get("runtime_readiness") if isinstance(card, dict) else None
        if not isinstance(readiness, dict):
            raise ValueError("Agent Hub schema 1.3 card is missing runtime_readiness.")
        valid = (
            readiness.get("structural_status") in {"ready", "blocked"}
            and readiness.get("configuration_status") in configuration_statuses
            and isinstance(readiness.get("run_action_enabled"), bool)
            and isinstance(readiness.get("reason"), str)
            and isinstance(readiness.get("runtime_dependencies"), list)
            and all(
                isinstance(item, str)
                for item in readiness.get("runtime_dependencies", [])
            )
            and isinstance(readiness.get("external_llm_required"), bool)
            and isinstance(readiness.get("live_health_verified"), bool)
            and readiness.get("semantic_validation_status")
            in {"verified", "not_verified"}
            and readiness.get("production_approval_status")
            in {"approved", "not_approved"}
        )
        if not valid:
            raise ValueError(
                "Agent Hub runtime_readiness failed schema 1.3 validation."
            )
        if readiness["run_action_enabled"] and (
            readiness["structural_status"] != "ready"
            or readiness["configuration_status"] in {"not_checked", "unavailable"}
        ):
            raise ValueError(
                "Agent Hub runtime_readiness enables an unavailable Agent."
            )
        if (
            readiness["configuration_status"] == "local_ready"
            and readiness["external_llm_required"] is not False
        ) or (
            readiness["configuration_status"] == "configured_not_live_verified"
            and readiness["external_llm_required"] is not True
        ):
            raise ValueError(
                "Agent Hub runtime_readiness dependency classification is inconsistent."
            )
    return cast(AgentHubResponse, value)


@dataclass
class User:
    id: str
    username: str
    email: str
    full_name: str = ""
    role: str = "coder"
    department: str = ""
    is_active: bool = True


@dataclass
class TokenResponse:
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: Optional[User] = None


@dataclass
class FactDiagnosis:
    diagnosis: str
    icd10cm_code: Optional[str] = None
    status: Optional[str] = None
    evidence: Optional[str] = None


@dataclass
class FactProcedure:
    procedure: str
    icd9cm3_code: Optional[str] = None
    status: Optional[str] = None
    evidence: Optional[str] = None


@dataclass
class FactExtractionResult:
    chief_complaint: Optional[str] = None
    diagnosis_facts: list[FactDiagnosis] = field(default_factory=list)
    procedure_facts: list[FactProcedure] = field(default_factory=list)
    negated_findings: list[dict] = field(default_factory=list)
    timing_facts: dict = field(default_factory=dict)
    documentation_overview: dict = field(default_factory=dict)


@dataclass
class FactItem:
    group: str
    text: str
    value: str = ""


@dataclass
class FactUsageInfo:
    credits_consumed: float = 0


@dataclass
class FactExtractResponse:
    facts: list[FactItem] = field(default_factory=list)
    output_language: str = "zh-CN"
    usage_info: FactUsageInfo = field(default_factory=FactUsageInfo)


@dataclass
class Review:
    id: Optional[str] = None
    encounter_id: Optional[str] = None
    status: Optional[str] = None
    primary_diagnosis: Optional[dict] = None
    main_procedure: Optional[dict] = None
    candidates: list[dict] = field(default_factory=list)
    evidences: list[dict] = field(default_factory=list)
    processing_time_ms: Optional[int] = None


@dataclass
class Expert:
    id: str
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    is_published: bool = False


@dataclass
class AgentTemplate:
    id: str
    name: str
    description: str = ""
    category: str = "general"
    system_prompt: Optional[str] = None
    expert_ids: list[str] = field(default_factory=list)


@dataclass
class UsageSummary:
    total_requests: int = 0
    credits_used: float = 0
    avg_response_time_ms: float = 0
    tokens_used: Optional[int] = None


@dataclass
class iCoDerConfig:
    base_url: str
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    timeout: int = 120


T = TypeVar("T")


@dataclass
class HttpResult(Generic[T]):
    """Response value plus protocol metadata such as 202 Location."""

    data: T
    status_code: int
    location: Optional[str] = None
