"""iCoDer Python SDK for a medical AI agent platform serving Chinese hospitals."""

from .client import iCoDerClient, iCoDerConfig
from .resources.facts import FactsResource
from .resources.agents import AgentsResource, ExpertsResource
from .resources.reviews import ReviewsResource
from .resources.speech_to_text import SpeechToTextResource
from .resources.textgen import TextGenResource
from .resources.billing import BillingResource, UsageResource
from .resources.oauth import OAuthResource
from .resources.runs import (
    AgentHubResource,
    RunEventRetentionError,
    RunEventStreamError,
    RunsResource,
)
from .resources.platform import PlatformResource
from .resources.a2a import A2AProtocolError, A2AResource, A2ATransportError
from .resources.documents import DocumentsResource
from .resources.templates import TemplatesResource
from .resources.medical_coding import CodingMode, MedicalCodingResource
from .resources.models import (
    ModelCatalog,
    ModelCatalogItem,
    ModelLiveCanaryPolicy,
    ModelLiveCanaryResponse,
    ModelsResource,
)
from .resources.drg_dip_risk_review import (
    DrgDipAnalyzeResponse,
    DrgDipCode,
    DrgDipGovernance,
    DrgDipImpact,
    DrgDipRiskReviewResource,
    DrgDipRulesResponse,
)
from .types import (
    FactExtractionResult, FactExtractResponse, FactItem, FactUsageInfo,
    FactDiagnosis, FactProcedure, Review, Expert, AgentTemplate,
    HttpResult, TokenResponse, UsageSummary, User,
)

__version__ = "1.0.0b17"
__all__ = [
    "iCoDerClient", "iCoDerConfig",
    "FactsResource", "AgentsResource", "ExpertsResource",
    "ReviewsResource", "SpeechToTextResource", "TextGenResource",
    "BillingResource", "UsageResource", "OAuthResource",
    "AgentHubResource", "RunsResource", "RunEventStreamError", "RunEventRetentionError", "PlatformResource", "A2AResource", "A2AProtocolError", "A2ATransportError", "HttpResult",
    "DocumentsResource", "TemplatesResource", "MedicalCodingResource", "CodingMode",
    "ModelsResource", "ModelCatalog", "ModelCatalogItem",
    "ModelLiveCanaryPolicy", "ModelLiveCanaryResponse",
    "DrgDipRiskReviewResource", "DrgDipGovernance", "DrgDipCode",
    "DrgDipAnalyzeResponse", "DrgDipImpact", "DrgDipRulesResponse",
    "FactItem", "FactUsageInfo", "FactExtractResponse",
]
