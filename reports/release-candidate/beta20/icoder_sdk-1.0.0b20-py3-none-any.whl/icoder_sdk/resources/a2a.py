"""A2A v0.3 Context plus v1 synchronous/asynchronous Task resources."""

from __future__ import annotations

import json
import time
from typing import Any, Iterator, Optional, Union
from urllib.parse import quote
from uuid import uuid4

from ..client import iCoDerClient


class A2AProtocolError(RuntimeError):
    """Protocol error that deliberately does not retain response details/body."""

    def __init__(
        self,
        jsonrpc_code: int,
        a2a_error_code: Optional[str] = None,
        http_status: Optional[int] = None,
    ) -> None:
        label = a2a_error_code or str(jsonrpc_code)
        super().__init__(f"iCoDer A2A request failed ({label})")
        self.jsonrpc_code = jsonrpc_code
        self.a2a_error_code = a2a_error_code
        self.http_status = http_status


class A2ATransportError(RuntimeError):
    """HTTP error that deliberately does not retain request/response objects."""

    def __init__(self, http_status: Optional[int] = None) -> None:
        suffix = f" (HTTP {http_status})" if http_status else ""
        super().__init__(f"iCoDer A2A transport failed{suffix}")
        self.http_status = http_status


def _raise_transport_error(status_code: int) -> None:
    if status_code < 200 or status_code >= 300:
        raise A2ATransportError(status_code)


def _raise_protocol_error(payload: Any, status_code: int) -> None:
    if not isinstance(payload, dict) or not isinstance(payload.get("error"), dict):
        return
    error = payload["error"]
    code = error.get("code")
    if not isinstance(code, int):
        return
    data = error.get("data")
    business_code = data.get("a2a_error_code") if isinstance(data, dict) else None
    # A2A v1 uses google.rpc.Status details / JSON-RPC Any details rather
    # than the v0.3 business-code object. Extract only the stable reason and
    # deliberately discard all descriptions and raw response content.
    details = data if isinstance(data, list) else error.get("details")
    if not isinstance(business_code, str) and isinstance(details, list):
        for detail in details:
            if isinstance(detail, dict) and isinstance(detail.get("reason"), str):
                business_code = detail["reason"]
                break
    raise A2AProtocolError(
        code,
        business_code if isinstance(business_code, str) else None,
        status_code,
    )


class A2AResource:
    def __init__(self, client: iCoDerClient):
        self._client = client

    def message_send(
        self,
        agent_id: str,
        parts: Union[str, list[dict[str, Any]]],
        *,
        context_id: Optional[str] = None,
        message_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        normalized_parts = (
            [{"kind": "text", "text": parts}] if isinstance(parts, str) else parts
        )
        message: dict[str, Any] = {
            "role": "user",
            "parts": normalized_parts,
            "messageId": message_id or f"msg-{uuid4()}",
        }
        if context_id:
            message["contextId"] = context_id
        if metadata:
            message["metadata"] = metadata
        response = self._client.post(
            f"/api/icoder/agents/{quote(agent_id, safe='')}/v1/message:send",
            headers={"A2A-Protocol-Version": "0.3"},
            json={
                "jsonrpc": "2.0",
                "id": f"rpc-{uuid4()}",
                "method": "message/send",
                "params": {"message": message},
            },
        )
        try:
            payload = response.json()
        except ValueError:
            _raise_transport_error(response.status_code)
            raise RuntimeError("iCoDer returned a non-JSON A2A response")
        _raise_protocol_error(payload, response.status_code)
        _raise_transport_error(response.status_code)
        result = payload.get("result") if isinstance(payload, dict) else None
        if not isinstance(result, dict):
            raise RuntimeError("iCoDer returned an incomplete A2A response")
        return result

    def message_stream(
        self,
        agent_id: str,
        parts: Union[str, list[dict[str, Any]]],
        *,
        context_id: Optional[str] = None,
        message_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ):
        """Yield raw SSE ``data`` payloads from authenticated A2A streaming."""
        normalized_parts = (
            [{"kind": "text", "text": parts}] if isinstance(parts, str) else parts
        )
        message: dict[str, Any] = {
            "role": "user",
            "parts": normalized_parts,
            "messageId": message_id or f"msg-{uuid4()}",
        }
        if context_id:
            message["contextId"] = context_id
        if metadata:
            message["metadata"] = metadata
        body = {
            "jsonrpc": "2.0",
            "id": f"rpc-{uuid4()}",
            "method": "message/stream",
            "params": {"message": message},
        }
        path = (
            f"/api/icoder/agents/{quote(agent_id, safe='')}/v1/message:stream"
        )
        for attempt in range(2):
            with self._client.http.stream(
                "POST",
                path,
                headers={
                    "A2A-Protocol-Version": "0.3",
                    "Accept": "text/event-stream",
                },
                json=body,
                timeout=self._client.config.timeout,
            ) as response:
                if (
                    response.status_code == 401
                    and attempt == 0
                    and self._client._refresh_token()
                ):
                    continue
                _raise_transport_error(response.status_code)
                content_type = response.headers.get("content-type", "")
                if not content_type.startswith("text/event-stream"):
                    raise A2ATransportError(response.status_code)
                for line in response.iter_lines():
                    if line.startswith("data:"):
                        yield line[5:].lstrip()
                return

    def get_context(
        self,
        agent_id: str,
        context_id: str,
        *,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        response = self._client.get(
            f"/api/icoder/agents/{quote(agent_id, safe='')}/v1/contexts/"
            f"{quote(context_id, safe='')}",
            headers={"A2A-Protocol-Version": "0.3"},
            params={"limit": limit, "offset": offset},
        )
        try:
            payload = response.json()
        except ValueError:
            _raise_transport_error(response.status_code)
            raise RuntimeError("iCoDer returned a non-JSON Context response")
        _raise_protocol_error(payload, response.status_code)
        _raise_transport_error(response.status_code)
        if not isinstance(payload, dict):
            raise RuntimeError("iCoDer returned an incomplete Context response")
        return payload

    def delete_context(self, context_id: str) -> dict[str, Any]:
        response = self._client.delete(
            f"/api/icoder/contexts/{quote(context_id, safe='')}",
            headers={"A2A-Protocol-Version": "0.3"},
        )
        try:
            payload = response.json()
        except ValueError:
            _raise_transport_error(response.status_code)
            raise RuntimeError("iCoDer returned a non-JSON A2A delete response")
        _raise_protocol_error(payload, response.status_code)
        _raise_transport_error(response.status_code)
        result = payload.get("result") if isinstance(payload, dict) else None
        if not isinstance(result, dict):
            raise RuntimeError("iCoDer returned an incomplete A2A delete response")
        return result

    @staticmethod
    def _v1_headers() -> dict[str, str]:
        return {"A2A-Version": "1.0"}

    @staticmethod
    def _v1_message(
        parts: Union[str, list[dict[str, Any]]],
        *,
        context_id: Optional[str],
        message_id: Optional[str],
        metadata: Optional[dict[str, Any]],
    ) -> dict[str, Any]:
        normalized_parts = (
            [{"text": parts, "mediaType": "text/plain"}]
            if isinstance(parts, str)
            else parts
        )
        message: dict[str, Any] = {
            "role": "ROLE_USER",
            "parts": normalized_parts,
            "messageId": message_id or f"msg-{uuid4()}",
        }
        if context_id:
            message["contextId"] = context_id
        if metadata:
            message["metadata"] = metadata
        return message

    def message_send_v1(
        self,
        agent_id: str,
        parts: Union[str, list[dict[str, Any]]],
        *,
        context_id: Optional[str] = None,
        message_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
        return_immediately: bool = False,
        accepted_output_modes: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """Send an A2A v1 Message; optionally return a durable submitted Task."""

        configuration: dict[str, Any] = {
            "returnImmediately": return_immediately,
        }
        if accepted_output_modes:
            configuration["acceptedOutputModes"] = accepted_output_modes
        response = self._client.post(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/message:send",
            headers=self._v1_headers(),
            json={
                "message": self._v1_message(
                    parts,
                    context_id=context_id,
                    message_id=message_id,
                    metadata=metadata,
                ),
                "configuration": configuration,
            },
        )
        try:
            payload = response.json()
        except ValueError:
            _raise_transport_error(response.status_code)
            raise RuntimeError("iCoDer returned a non-JSON A2A v1 response")
        _raise_protocol_error(payload, response.status_code)
        _raise_transport_error(response.status_code)
        if not isinstance(payload, dict) or not (
            isinstance(payload.get("message"), dict)
            or isinstance(payload.get("task"), dict)
        ):
            raise RuntimeError("iCoDer returned an incomplete A2A v1 response")
        return payload

    def get_task_v1(self, agent_id: str, task_id: str) -> dict[str, Any]:
        response = self._client.get(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/tasks/"
            f"{quote(task_id, safe='')}",
            headers=self._v1_headers(),
        )
        return self._v1_object_response(response, "Task")

    def list_tasks_v1(
        self,
        agent_id: str,
        *,
        context_id: Optional[str] = None,
        status: Optional[str] = None,
        page_size: int = 50,
        page_token: Optional[str] = None,
        status_timestamp_after: Optional[str] = None,
        include_artifacts: bool = False,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {
            "pageSize": page_size,
            "includeArtifacts": include_artifacts,
        }
        if context_id:
            params["contextId"] = context_id
        if status:
            params["status"] = status
        if page_token:
            params["pageToken"] = page_token
        if status_timestamp_after:
            params["statusTimestampAfter"] = status_timestamp_after
        response = self._client.get(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/tasks",
            headers=self._v1_headers(),
            params=params,
        )
        payload = self._v1_object_response(response, "Task list")
        if not isinstance(payload.get("tasks"), list):
            raise RuntimeError("iCoDer returned an incomplete A2A v1 Task list")
        return payload

    def cancel_task_v1(self, agent_id: str, task_id: str) -> dict[str, Any]:
        response = self._client.post(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/tasks/"
            f"{quote(task_id, safe='')}:cancel",
            headers=self._v1_headers(),
            json={},
        )
        return self._v1_object_response(response, "Task")

    def wait_task_v1(
        self,
        agent_id: str,
        task_id: str,
        *,
        timeout: float = 60.0,
        poll_interval: float = 0.25,
    ) -> dict[str, Any]:
        """Poll a Task to a terminal state without hiding failed/canceled states."""

        if timeout <= 0 or poll_interval <= 0:
            raise ValueError("timeout and poll_interval must be positive")
        terminal = {
            "TASK_STATE_COMPLETED",
            "TASK_STATE_FAILED",
            "TASK_STATE_CANCELED",
        }
        deadline = time.monotonic() + timeout
        while True:
            task = self.get_task_v1(agent_id, task_id)
            status = task.get("status") if isinstance(task.get("status"), dict) else {}
            if status.get("state") in terminal:
                return task
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError(f"A2A v1 Task {task_id!r} did not reach a terminal state")
            time.sleep(min(poll_interval, remaining))

    def subscribe_task_v1(
        self,
        agent_id: str,
        task_id: str,
        *,
        after_sequence: int = 0,
        last_event_id: Optional[str] = None,
    ) -> Iterator[dict[str, Any]]:
        """Yield decoded durable Task events and support Last-Event-ID resume."""

        if after_sequence < 0:
            raise ValueError("after_sequence must be non-negative")
        path = (
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/tasks/"
            f"{quote(task_id, safe='')}:subscribe"
        )
        headers = {
            **self._v1_headers(),
            "Accept": "text/event-stream",
        }
        if last_event_id:
            headers["Last-Event-ID"] = last_event_id
        for attempt in range(2):
            with self._client.http.stream(
                "GET",
                path,
                headers=headers,
                params={"afterSequence": after_sequence},
                timeout=self._client.config.timeout,
            ) as response:
                if (
                    response.status_code == 401
                    and attempt == 0
                    and self._client._refresh_token()
                ):
                    continue
                if not 200 <= response.status_code < 300:
                    try:
                        _raise_protocol_error(response.json(), response.status_code)
                    except ValueError:
                        pass
                    _raise_transport_error(response.status_code)
                if not response.headers.get("content-type", "").startswith(
                    "text/event-stream"
                ):
                    raise A2ATransportError(response.status_code)
                data_lines: list[str] = []
                event_id = ""
                event_type = "message"
                for line in response.iter_lines():
                    if not line:
                        if data_lines:
                            try:
                                payload = json.loads("\n".join(data_lines))
                            except json.JSONDecodeError as exc:
                                raise A2ATransportError(response.status_code) from exc
                            if not isinstance(payload, dict):
                                raise A2ATransportError(response.status_code)
                            payload.setdefault("eventId", event_id)
                            payload.setdefault("eventType", event_type)
                            yield payload
                        data_lines = []
                        event_id = ""
                        event_type = "message"
                    elif line.startswith("data:"):
                        data_lines.append(line[5:].lstrip())
                    elif line.startswith("id:"):
                        event_id = line[3:].lstrip()
                    elif line.startswith("event:"):
                        event_type = line[6:].lstrip()
                if data_lines:
                    try:
                        payload = json.loads("\n".join(data_lines))
                    except json.JSONDecodeError as exc:
                        raise A2ATransportError(response.status_code) from exc
                    if not isinstance(payload, dict):
                        raise A2ATransportError(response.status_code)
                    payload.setdefault("eventId", event_id)
                    payload.setdefault("eventType", event_type)
                    yield payload
                return

    def export_context_traces(
        self,
        context_id: str,
        *,
        page_size: int = 50,
        page_token: Optional[str] = None,
    ) -> dict[str, Any]:
        """Export a Context's newest-first OpenInference-shaped trace page."""
        if page_size < 1 or page_size > 200:
            raise ValueError("page_size must be between 1 and 200")
        params: dict[str, Any] = {"pageSize": page_size}
        if page_token:
            params["pageToken"] = page_token
        response = self._client.get(
            f"/api/v2/agentic/contexts/{quote(context_id, safe='')}/trace",
            headers=self._v1_headers(),
            params=params,
        )
        payload = self._v1_object_response(response, "trace page")
        if not isinstance(payload.get("traces"), list):
            raise RuntimeError("iCoDer returned an incomplete Agentic trace page")
        return payload

    def get_agent_usage(
        self,
        agent_id: str,
        *,
        from_time: Optional[str] = None,
        to_time: Optional[str] = None,
        granularity: str = "day",
    ) -> dict[str, Any]:
        """Return daily invocation and unique-Context usage for one Agent."""
        if granularity not in {"minute", "hour", "day", "week"}:
            raise ValueError("granularity must be minute, hour, day, or week")
        params: dict[str, Any] = {"granularity": granularity}
        if from_time:
            params["from"] = from_time
        if to_time:
            params["to"] = to_time
        response = self._client.get(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/usage",
            headers=self._v1_headers(),
            params=params,
        )
        payload = self._v1_object_response(response, "Agent usage")
        if (
            payload.get("granularity") != "day"
            or not isinstance(payload.get("totals"), dict)
            or not isinstance(payload.get("buckets"), list)
        ):
            raise RuntimeError("iCoDer returned an incomplete Agent usage response")
        return payload

    def submit_task_feedback(
        self,
        context_id: str,
        task_id: str,
        feedback: dict[str, Any],
    ) -> dict[str, Any]:
        response = self._client.post(
            f"/api/v2/agentic/contexts/{quote(context_id, safe='')}/tasks/"
            f"{quote(task_id, safe='')}/feedback",
            headers=self._v1_headers(),
            json=feedback,
        )
        return self._v1_object_response(response, "feedback")

    def list_task_feedback(self, context_id: str, task_id: str) -> dict[str, Any]:
        response = self._client.get(
            f"/api/v2/agentic/contexts/{quote(context_id, safe='')}/tasks/"
            f"{quote(task_id, safe='')}/feedback",
            headers=self._v1_headers(),
        )
        payload = self._v1_object_response(response, "feedback list")
        if not isinstance(payload.get("feedbacks"), list):
            raise RuntimeError("iCoDer returned an incomplete Agentic feedback list")
        return payload

    def delete_task_feedback(self, context_id: str, task_id: str) -> None:
        response = self._client.delete(
            f"/api/v2/agentic/contexts/{quote(context_id, safe='')}/tasks/"
            f"{quote(task_id, safe='')}/feedback",
            headers=self._v1_headers(),
        )
        _raise_transport_error(response.status_code)

    @staticmethod
    def _v1_object_response(response: Any, label: str) -> dict[str, Any]:
        try:
            payload = response.json()
        except ValueError:
            _raise_transport_error(response.status_code)
            raise RuntimeError(f"iCoDer returned a non-JSON A2A v1 {label} response")
        _raise_protocol_error(payload, response.status_code)
        _raise_transport_error(response.status_code)
        if not isinstance(payload, dict):
            raise RuntimeError(f"iCoDer returned an incomplete A2A v1 {label} response")
        return payload
