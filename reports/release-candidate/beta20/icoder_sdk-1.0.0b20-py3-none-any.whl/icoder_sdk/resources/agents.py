"""Agents & Experts resources."""

from __future__ import annotations
from typing import Any, Optional
from urllib.parse import quote

from ..client import iCoDerClient


class AgentsResource:
    def __init__(self, client: iCoDerClient):
        self._client = client

    def list(self, category: str = "", search: str = "") -> dict:
        resp = self._client.get(
            "/api/rest/v1/agent_definitions",
            params={"category": category, "search": search},
        )
        resp.raise_for_status()
        return resp.json()

    def get(self, agent_id: str) -> dict:
        resp = self._client.get(
            f"/api/rest/v1/agent_definitions/{quote(agent_id, safe='')}"
        )
        resp.raise_for_status()
        return resp.json()

    def hub(self, use_case: str = "") -> dict:
        """List Corti-style prebuilt Agent Hub cards and typed contracts."""
        resp = self._client.get(
            "/api/icoder/agents/hub",
            params={"use_case": use_case} if use_case else None,
        )
        resp.raise_for_status()
        return resp.json()

    def card(self, agent_id: str) -> dict:
        """Get one runtime Agent Card by URL-safe Agent id."""
        resp = self._client.get(
            f"/api/icoder/agents/{quote(agent_id, safe='')}/card"
        )
        resp.raise_for_status()
        return resp.json()

    def create(self, name: str, description: str = "", category: str = "",
               system_prompt: str = "", expert_ids: Optional[list[str]] = None) -> dict:
        resp = self._client.post("/api/rest/v1/agent_definitions", json={
            "name": name, "description": description, "category": category,
            "system_prompt": system_prompt, "expert_ids": expert_ids or [],
        })
        resp.raise_for_status()
        return resp.json()

    def update(self, agent_id: str, **kwargs) -> dict:
        resp = self._client.put(
            f"/api/rest/v1/agent_definitions/{quote(agent_id, safe='')}",
            json=kwargs,
        )
        resp.raise_for_status()
        return resp.json()

    def delete(self, agent_id: str) -> None:
        resp = self._client.delete(
            f"/api/rest/v1/agent_definitions/{quote(agent_id, safe='')}"
        )
        resp.raise_for_status()

    def list_connectors(self, agent_id: str) -> dict:
        resp = self._client.get(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/connectors"
        )
        resp.raise_for_status()
        return resp.json()

    def create_connector(
        self,
        agent_id: str,
        *,
        connector_type: str,
        name: str,
        config: dict[str, Any],
        description: str = "",
        enabled: bool = False,
    ) -> dict:
        resp = self._client.post(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/connectors",
            json={
                "type": connector_type,
                "name": name,
                "description": description,
                "enabled": enabled,
                "config": config,
            },
        )
        resp.raise_for_status()
        return resp.json()

    def update_connector(
        self,
        agent_id: str,
        connector_id: str,
        *,
        expected_version: int,
        **changes: Any,
    ) -> dict:
        resp = self._client.patch(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/connectors/"
            f"{quote(connector_id, safe='')}",
            json={"expected_version": expected_version, **changes},
        )
        resp.raise_for_status()
        return resp.json()

    def delete_connector(self, agent_id: str, connector_id: str) -> None:
        resp = self._client.delete(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/connectors/"
            f"{quote(connector_id, safe='')}"
        )
        resp.raise_for_status()

    def bind_connector_credential(
        self,
        agent_id: str,
        connector_id: str,
        *,
        provider: str,
        secret_ref: str,
        secret_type: str,
        expected_version: int | None = None,
    ) -> dict:
        payload: dict[str, Any] = {
            "provider": provider,
            "secret_ref": secret_ref,
            "secret_type": secret_type,
        }
        if expected_version is not None:
            payload["expected_version"] = expected_version
        resp = self._client.put(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/connectors/"
            f"{quote(connector_id, safe='')}/credential",
            json=payload,
        )
        resp.raise_for_status()
        return resp.json()

    def delete_connector_credential(self, agent_id: str, connector_id: str) -> None:
        resp = self._client.delete(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/connectors/"
            f"{quote(connector_id, safe='')}/credential"
        )
        resp.raise_for_status()

    def connector_graph(self, agent_id: str) -> dict:
        resp = self._client.get(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/connector-graph"
        )
        resp.raise_for_status()
        return resp.json()

    def put_connector_graph(
        self,
        agent_id: str,
        *,
        expected_revision: int,
        enabled: bool,
        nodes: list[dict[str, Any]],
    ) -> dict:
        resp = self._client.put(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/connector-graph",
            json={
                "version": "1.0",
                "enabled": enabled,
                "execution_mode": "sequential",
                "nodes": nodes,
                "expected_revision": expected_revision,
            },
        )
        resp.raise_for_status()
        return resp.json()

    def delete_connector_graph(self, agent_id: str, *, expected_revision: int) -> None:
        resp = self._client.delete(
            f"/api/v2/agentic/agents/{quote(agent_id, safe='')}/connector-graph",
            params={"expected_revision": expected_revision},
        )
        resp.raise_for_status()

    def run(self, agent_id: str, input_text: str) -> dict:
        return self._client.a2a.message_send(agent_id, input_text)

    def stream(self, agent_id: str, input_text: str):
        """Stream authenticated A2A SSE payloads from the runtime Agent."""
        yield from self._client.a2a.message_stream(agent_id, input_text)

    def templates(self) -> dict:
        resp = self._client.get("/api/rest/v1/agent_definitions/templates")
        resp.raise_for_status()
        return resp.json()


class ExpertsResource:
    def __init__(self, client: iCoDerClient):
        self._client = client

    def list(self, category: str = "", search: str = "") -> dict:
        resp = self._client.get("/api/experts", params={"category": category, "search": search})
        resp.raise_for_status()
        return resp.json()

    def call(self, name: str, input_text: str) -> dict:
        from urllib.parse import quote
        resp = self._client.post(
            f"/api/experts/call/{quote(name)}?input={quote(input_text)}"
        )
        resp.raise_for_status()
        return resp.json()

    def create(self, name: str, category: str, description: str = "") -> dict:
        resp = self._client.post("/api/experts", json={
            "name": name, "category": category, "description": description,
        })
        resp.raise_for_status()
        return resp.json()

    def delete(self, expert_id: str) -> None:
        resp = self._client.delete(f"/api/experts/{expert_id}")
        resp.raise_for_status()
