# iCoDer Python SDK

面向中国医院场景的 iCoDer API Python 客户端。当前开发候选版覆盖 Agent Hub、统一 Agent Run、A2A 多轮 Context、事实提取、编码审核，以及可持久化的 v2 录音与转写生命周期。

## A2A 多轮 Context

```python
first = client.a2a.message_send("note-completeness-agent", "第一轮")
second = client.a2a.message_send(
    "note-completeness-agent", "继续上一轮", context_id=first["contextId"]
)
history = client.a2a.get_context(
    "note-completeness-agent", second["contextId"]
)
client.a2a.delete_context(history["id"])
```

## A2A v1 持久化异步 Task

```python
submitted = client.a2a.message_send_v1(
    "note-completeness-agent",
    "去标识病历文本",
    return_immediately=True,
)
task_id = submitted["task"]["id"]

for event in client.a2a.subscribe_task_v1(
    "note-completeness-agent", task_id, after_sequence=0
):
    print(event["eventId"], event["eventType"])

terminal = client.a2a.wait_task_v1("note-completeness-agent", task_id)
if terminal["status"]["state"] != "TASK_STATE_COMPLETED":
    # failed/canceled 是真实终态，不应显示为成功。
    pass
```

## 安装

发布到 PyPI 前，请从仓库源码安装：

```bash
python -m pip install ./packages/icoder-python
```

要求 Python 3.9 或更高版本。

## 快速开始

```python
from icoder_sdk import iCoDerClient, iCoDerConfig

client = iCoDerClient(iCoDerConfig(
    base_url="https://api.example.cn",
    access_token="<tenant-bound-access-token>",
))

hub = client.agent_hub.list()
run = client.runs.run_text(
    "medical-coding-agent",
    "患者因胸痛入院……",
    idempotency_key="encounter-001",
)
print(hub["total"], run.get("trace_id"))

status = client.runs.get(run["run_id"])
cancellation = client.runs.cancel(run["run_id"], "operator request")
```

## Agent Connector Graph

Connector 资源和执行图由 owner/admin 管理，运行时只能从受审计的 Agent Run 触发。节点
显式固定操作、输入字段、数据分类及用途，模型不能生成 URL、凭据或自由节点参数。

```python
connector = client.agents.create_connector(
    "custom-agent",
    connector_type="registry",
    name="Approved memory lookup",
    config={"registry_key": "memory", "capabilities": ["lookup"]},
)
client.agents.put_connector_graph(
    "custom-agent",
    expected_revision=0,
    enabled=True,
    nodes=[{
        "id": "lookup",
        "connector_id": connector["id"],
        "operation": "lookup",
        "required": True,
        "input_keys": ["code"],
        "data_classification": "deidentified",
        "purpose_of_use": "treatment",
    }],
)
```

认证信息只能通过 `bind_connector_credential` 提交外部 secret-manager 引用，不能把真实
API Key 放进 Connector `config`。必需节点失败或输出安全检查失败时，服务端禁止模型调用和结果发布。

For long-running consumers, the bounded resilient iterator preserves the last
event cursor and renews an expired signed trace token through the configured
bearer identity. It does not hide cursor, tenant, authorization or protocol
errors:

```python
for event in client.runs.stream_events_resilient(
    run["run_id"], trace_token,
    max_attempts=4, initial_delay=0.25, max_delay=4.0,
):
    print(event.get("meta", {}).get("event_id"), event["name"])
```

If the retained trace or resume cursor has expired, both stream methods raise
`RunEventRetentionError` with a safe `error_code` and `retention_days`. This
HTTP 410 condition is terminal, is not retried, and does not retain the raw
response body.

取消结果必须读取 `cancellation["outcome"]`：`RECORDED_ONLY` 表示请求已审计但 Provider
仍在运行，不能当作已取消。`client.runs.stream_events(run_id, trace_token)` 提供签名、去 PHI
的 SSE 生命周期事件；`trace_token` 来自 Agent Run `trace_url` 的 `token` 查询参数。
断线后可把最后一个 envelope 的 `meta.event_id` 作为
`last_event_id=` 再次调用，从下一条 trace 恢复。

## Medical Coding 过滤

```python
coding = client.medical_coding.predict(
    "患者有2型糖尿病史。",
    coding_systems=["icd10cn", "icd9cm3"],
    include_codes=["E11"],
    exclude_codes=["E11.0"],
    expand_categories=True,
)
print(coding["codes"])
```

中国编码入口支持单独或同时请求 `icd10cn` 诊断和 `icd9cm3` 手术操作。类别展开开启时
按前缀匹配叶子编码，关闭时只做完整编码匹配；服务端会再次确定性强制过滤。

## Models 受控实网 Canary

```python
catalog = client.models.get_catalog()
if catalog["live_canary_available"]:
    canary = client.models.live_canary(
        catalog["effective_deployment_id"],
        max_cost_cny=catalog["live_canary_policy"]["max_cost_cny"],
    )
    print(canary["status"], canary["latency_ms"], canary["cost"]["amount"])
```

该方法不接受提示词或病例文本，只发送服务端固定无患者数据载荷，且不返回模型正文。
owner/admin、显式开关、区域外发许可、费用上限和冷却时间全部通过后才会调用一次 Provider；
结果只证明当次连通性。

开发环境可使用 `http://127.0.0.1:8000`。生产环境应使用 HTTPS，并使用绑定组织租户的短期访问令牌。

## v2 录音与转写

```python
recording = client.speech_to_text.upload_recording(
    "interaction-001",
    b"synthetic-audio-for-development",
    "audio/wav",
)
transcript = client.speech_to_text.create_transcript(
    "interaction-001",
    recording["recordingId"],
    primary_language="zh-CN",
    async_=True,
)
print(transcript.status_code, transcript.location)
```

SDK 在上传前执行 150 MB 客户端限制；服务端仍是最终的鉴权、租户隔离和大小校验边界。

## 实时语音转写

```python
session = await client.speech_to_text.create_session_async(language="zh-CN")
await session.send(audio_chunk)
await session.send(json.dumps({"type": "interim"}))
await session.send(json.dumps({"type": "end"}))
```

`create_session_async()` 只有在服务端完成 tenant token 鉴权并返回 `ready` 后才成功；
连接/协议错误或 5 秒超时均关闭连接并抛出不保留 token URI 的安全异常。WebSocket 依赖
按需安装：`python -m pip install websockets`。当前验证范围仅含中文、自动标点和
WebM/Opus start，32 MiB 会话总量仍由服务端强制。

## Documents 与 Templates

```python
sections = client.templates.list_sections(
    lang=["zh-CN"], region=["CHN"]
)
preview = client.documents.preview(
    "11111111-1111-4111-8111-111111111111",
    {
        "context": [{"type": "string", "data": "去标识临床样例文本"}],
        "template": {
            "sections": [
                {"key": section["id"], "nameOverride": section["name"]}
                for section in sections[:2]
            ]
        },
        "outputLanguage": "zh-CN",
        "documentationMode": "global_sequential",
    },
)
print(preview["sections"], preview["usageInfo"]["creditsConsumed"])
```

`documents.preview()` 强制使用零保留策略，并在服务端未返回 `acknowledged` 时失败关闭。生成内容必须由临床人员复核。

## Facts 与 Text Generation 兼容入口

```python
facts = client.facts.extract("患者主诉胸痛。", output_language="zh-CN")
generated = client.textgen.generate(
    "去标识临床文本", template="出院小结", output_language="zh-CN"
)
print(facts.usage_info.credits_consumed, generated["credits_consumed"])
```

`textgen.generate()` 是旧调用面的兼容 facade，实际使用 Guided Documents `dynamicTemplate`。它强制生成文书零留存确认；动态模板与 Section 元数据仍会登记在当前租户，因此模板名称不得包含患者标识。`doc_name`、非默认 `max_tokens` 和非默认 `temperature` 当前不受 Guided 合同支持，会在发送前失败关闭。新集成应优先直接使用 Guided Documents 请求。

## 资源

| 属性 | 能力 |
| --- | --- |
| `client.agent_hub` | 列出面向用户的 Agent 卡片并读取单卡 |
| `client.runs` | 统一 Agent Run 与 trace 元数据 |
| `client.speech_to_text` | v2 录音/转写生命周期与鉴权实时 WebSocket |
| `client.documents` | Classic 文档生成、零保留预览及加密生命周期 |
| `client.templates` | Guided Template/Section 发现及租户 Section 管理 |
| `client.facts` | 临床事实提取 |
| `client.textgen` | Guided Documents 动态模板兼容生成（文书零留存） |
| `client.medical_coding` | 中国医学编码预测、Corti 风格代码过滤与预估费用 |
| `client.agents` / `client.experts` | Agent 与 Expert 管理 |
| `client.reviews` | 医学编码审核 |
| `client.billing` / `client.usage` | 计费和用量查询 |
| `client.oauth` | OAuth 客户端管理接口 |

## 当前发布状态

`1.0.0b20` 是开发发布候选版，新增 Corti alpha v2 对齐的 `workflow`、`parallel`、`stateGraph`、`agent_node` 编排原语和当前 Agent 用量合同，并保留 Context trace、调用方隔离反馈及 A2A v1 持久化异步 Task；中国医疗 trace 导出遵守最小必要原则，不返回原始病历输入或模型输出。多副本队列、真实医院验收和合规审批仍是外部门禁。该版本尚未发布到 PyPI，也不代表临床上线批准。
