import json

import httpx

from icoder_sdk import iCoDerClient, iCoDerConfig


def test_agents_resource_uses_definition_crud_and_a2a_execution_mainline():
    calls = []

    def handler(request):
        body = json.loads(request.content) if request.content else None
        raw_path = request.url.raw_path.decode().split("?", 1)[0]
        calls.append((request.method, raw_path, request.headers, body))
        if raw_path.endswith("/v1/message%3Asend") or raw_path.endswith("/v1/message:send"):
            return httpx.Response(200, json={
                "jsonrpc": "2.0",
                "id": body["id"],
                "result": {
                    "kind": "message",
                    "role": "agent",
                    "messageId": "result-1",
                    "contextId": "context-1",
                    "parts": [{"kind": "text", "text": "done"}],
                    "metadata": {},
                },
            })
        return httpx.Response(200, json={"agents": []})

    client = iCoDerClient(
        iCoDerConfig(base_url="https://api.cn.icoder.cloud", access_token="token")
    )
    client.http.close()
    client.http = httpx.Client(
        base_url=client.base_url,
        headers={"Authorization": "Bearer token"},
        transport=httpx.MockTransport(handler),
    )
    try:
        client.agents.list()
        result = client.agents.run("medical/coding", "de-identified note")
    finally:
        client.close()

    assert calls[0][1] == "/api/rest/v1/agent_definitions"
    assert calls[1][1] == "/api/icoder/agents/medical%2Fcoding/v1/message:send"
    assert calls[1][3]["method"] == "message/send"
    assert calls[1][2]["A2A-Protocol-Version"] == "0.3"
    assert result["contextId"] == "context-1"
    assert all(not path.startswith("/api/agents") for _, path, _, _ in calls)


def test_agents_resource_stream_uses_a2a_sse_contract():
    captured = []

    def handler(request):
        body = json.loads(request.content)
        captured.append((request, body))
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream; charset=utf-8"},
            content=b'event: data-json\ndata: {"jsonrpc":"2.0"}\n\nevent: done\ndata: {}\n\n',
        )

    client = iCoDerClient(
        iCoDerConfig(base_url="https://api.cn.icoder.cloud", access_token="token")
    )
    client.http.close()
    client.http = httpx.Client(
        base_url=client.base_url,
        headers={"Authorization": "Bearer token"},
        transport=httpx.MockTransport(handler),
    )
    try:
        chunks = list(client.agents.stream("note completeness", "safe input"))
    finally:
        client.close()

    request, body = captured[0]
    assert request.url.raw_path.decode() == (
        "/api/icoder/agents/note%20completeness/v1/message:stream"
    )
    assert request.headers["A2A-Protocol-Version"] == "0.3"
    assert request.headers["Authorization"] == "Bearer token"
    assert body["method"] == "message/stream"
    assert body["params"]["message"]["parts"][0]["text"] == "safe input"
    assert chunks == ['{"jsonrpc":"2.0"}', "{}"]


def test_agents_resource_exposes_hub_and_card_contract_routes():
    calls = []
    card = {
        "agent_id": "claim-check",
        "output_contract": {
            "schema_ref": "icoder/ClaimCheckOutput/v1",
            "required_fields": ["summary"],
            "optional_fields": ["details"],
            "field_types": {"summary": "string", "details": "array"},
            "field_schemas": {
                "summary": {"type": "string", "maxLength": 32768},
                "details": {
                    "type": "array",
                    "maxItems": 100,
                    "uniqueItems": True,
                    "items": {"type": "string", "enum": ["a", "b"]},
                },
            },
              "field_relations": [{
                  "id": "details_require_summary",
                  "for_each": "candidates",
                  "when": [{"path": "details", "operator": "non_empty"}],
                  "must": [{"path": "confidence", "operator": "gte", "value": 0.7}],
              }],
              "evidence_bindings": [{
                  "id": "candidate_evidence_matches_input",
                  "for_each": "candidates",
                  "text_path": "evidence_text",
                  "span_path": "char_span",
              }],
              "cross_agent_relations": [{
                  "id": "candidate_matches_upstream",
                  "local_path": "summary",
                  "upstream_agent_id": "upstream-agent",
                  "upstream_path": "items",
                  "upstream_item_path": "code",
                  "operator": "scalar_in_upstream_items",
                  "normalization": "medical_code",
                  "required": False,
              }],
        },
    }

    def handler(request):
        calls.append(request)
        if request.url.path.endswith("/card"):
            return httpx.Response(200, json=card)
        return httpx.Response(200, json={
            "agents": [card], "total": 1, "source": "packs", "schema_version": "1.1",
        })

    client = iCoDerClient(
        iCoDerConfig(base_url="https://api.cn.icoder.cloud", access_token="token")
    )
    client.http.close()
    client.http = httpx.Client(
        base_url=client.base_url,
        headers={"Authorization": "Bearer token"},
        transport=httpx.MockTransport(handler),
    )
    try:
        hub = client.agents.hub("coding_revenue_cycle")
        discovered = client.agents.card("claim/check")
    finally:
        client.close()

    assert calls[0].url.path == "/api/icoder/agents/hub"
    assert calls[0].url.params["use_case"] == "coding_revenue_cycle"
    assert calls[1].url.raw_path.decode() == "/api/icoder/agents/claim%2Fcheck/card"
    assert hub["agents"][0]["output_contract"]["optional_fields"] == ["details"]
    assert discovered["output_contract"]["field_types"]["details"] == "array"
    assert discovered["output_contract"]["field_schemas"]["details"]["items"]["type"] == "string"
    assert discovered["output_contract"]["field_schemas"]["summary"]["maxLength"] == 32768
    assert discovered["output_contract"]["field_schemas"]["details"]["maxItems"] == 100
    assert discovered["output_contract"]["field_schemas"]["details"]["items"]["enum"] == ["a", "b"]
    assert discovered["output_contract"]["field_relations"][0]["id"] == "details_require_summary"
    assert discovered["output_contract"]["field_relations"][0]["for_each"] == "candidates"
    assert discovered["output_contract"]["field_relations"][0]["must"][0]["operator"] == "gte"
    assert discovered["output_contract"]["evidence_bindings"][0]["span_path"] == "char_span"
    assert discovered["output_contract"]["cross_agent_relations"][0]["normalization"] == "medical_code"


def test_agents_resource_manages_connectors_and_optimistic_graph_revisions():
    calls = []

    def handler(request):
        body = json.loads(request.content) if request.content else None
        calls.append((request, body))
        if request.url.path.endswith("/connector-graph"):
            return httpx.Response(200, json={
                "version": "1.0",
                "enabled": True,
                "execution_mode": "sequential",
                "nodes": (body or {}).get("nodes", []),
                "revision": 1,
            })
        return httpx.Response(200, json={
            "id": "con-1",
            "agent_id": "agent/one",
            "type": "registry",
            "name": "Memory",
            "enabled": False,
            "config": {"registry_key": "memory"},
            "version": 1,
            "credential": {"present": False},
        })

    client = iCoDerClient(
        iCoDerConfig(base_url="https://api.cn.icoder.cloud", access_token="token")
    )
    client.http.close()
    client.http = httpx.Client(
        base_url=client.base_url,
        headers={"Authorization": "Bearer token"},
        transport=httpx.MockTransport(handler),
    )
    try:
        client.agents.create_connector(
            "agent/one",
            connector_type="registry",
            name="Memory",
            config={"registry_key": "memory", "capabilities": ["lookup"]},
        )
        client.agents.bind_connector_credential(
            "agent/one",
            "con/1",
            provider="vault",
            secret_ref="vault://tenant/connectors/memory",
            secret_type="bearer",
        )
        client.agents.put_connector_graph(
            "agent/one",
            expected_revision=0,
            enabled=True,
            nodes=[{"id": "lookup", "connector_id": "con-1", "operation": "lookup"}],
        )
        client.agents.delete_connector_graph("agent/one", expected_revision=1)
    finally:
        client.close()

    assert calls[0][0].url.raw_path.decode() == (
        "/api/v2/agentic/agents/agent%2Fone/connectors"
    )
    assert calls[0][1]["config"]["registry_key"] == "memory"
    assert calls[1][0].url.raw_path.decode() == (
        "/api/v2/agentic/agents/agent%2Fone/connectors/con%2F1/credential"
    )
    assert calls[1][1]["secret_ref"] == "vault://tenant/connectors/memory"
    assert calls[2][1]["expected_revision"] == 0
    assert calls[3][0].method == "DELETE"
    assert calls[3][0].url.params["expected_revision"] == "1"
