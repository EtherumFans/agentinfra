import httpx

from icoder_sdk import iCoDerClient, iCoDerConfig


def test_models_resource_reads_secret_free_catalog():
    calls = []

    def handler(request):
        calls.append((request.method, request.url.path))
        return httpx.Response(200, json={
            "active_provider": "mock",
            "active_model": "mock/1.0",
            "operator_default_provider": "mock",
            "operator_default_model": "mock/1.0",
            "effective_deployment_id": "mock",
            "tenant_selection": {"mode": "inherit", "deployment_id": None, "version": 0},
            "registered_deployments": [],
            "selection_editable": True,
            "tenant_region": "cn",
            "egress_policy": "strict",
            "external_llm_allowed": False,
            "models": [],
            "readiness_scope": "configuration_and_policy_only",
            "live_health_verified": False,
            "disclaimer": "configuration only",
        })

    client = iCoDerClient(
        iCoDerConfig(base_url="https://api.cn.icoder.cloud", access_token="token")
    )
    client.http.close()
    client.http = httpx.Client(
        base_url=client.base_url,
        headers={"Authorization": "Bearer token"},
        transport=httpx.MockTransport(handler),
    )
    try:
        result = client.models.get_catalog()
    finally:
        client.close()

    assert calls == [("GET", "/api/v1/model-catalog")]
    assert result["live_health_verified"] is False
    assert result["readiness_scope"] == "configuration_and_policy_only"


def test_models_resource_updates_versioned_tenant_selection():
    captured = {}

    def handler(request):
        captured["method"] = request.method
        captured["path"] = request.url.path
        captured["json"] = __import__("json").loads(request.content)
        return httpx.Response(200, json={
            "mode": "pinned", "deployment_id": "qwen-cn-a", "version": 2,
        })

    client = iCoDerClient(
        iCoDerConfig(base_url="https://api.cn.icoder.cloud", access_token="token")
    )
    client.http.close()
    client.http = httpx.Client(
        base_url=client.base_url,
        headers={"Authorization": "Bearer token"},
        transport=httpx.MockTransport(handler),
    )
    try:
        result = client.models.update_selection(
            mode="pinned", deployment_id="qwen-cn-a", expected_version=1,
        )
    finally:
        client.close()

    assert captured == {
        "method": "PUT",
        "path": "/api/v1/model-catalog/selection",
        "json": {
            "mode": "pinned",
            "deployment_id": "qwen-cn-a",
            "expected_version": 1,
        },
    }
    assert result["version"] == 2


def test_models_resource_runs_configuration_health_probe():
    captured = {}

    def handler(request):
        captured["method"] = request.method
        captured["path"] = request.url.path
        captured["json"] = __import__("json").loads(request.content)
        return httpx.Response(200, json={
            "deployment_id": "hospital-local",
            "provider_id": "local",
            "model": "hospital-model-v1",
            "status": "healthy",
            "probe_mode": "configuration",
            "egress_decision": "allow",
            "credential_configured": False,
            "circuit_open": False,
            "checked_at": "2026-08-21T00:00:00Z",
        })

    client = iCoDerClient(
        iCoDerConfig(base_url="https://api.cn.icoder.cloud", access_token="token")
    )
    client.http.close()
    client.http = httpx.Client(
        base_url=client.base_url,
        headers={"Authorization": "Bearer token"},
        transport=httpx.MockTransport(handler),
    )
    try:
        result = client.models.health_probe("hospital-local")
    finally:
        client.close()

    assert captured == {
        "method": "POST",
        "path": "/api/v1/model-catalog/health-probe",
        "json": {"deployment_id": "hospital-local"},
    }
    assert result["probe_mode"] == "configuration"


def test_models_resource_sends_fixed_explicit_live_canary_contract():
    captured = {}

    def handler(request):
        captured["method"] = request.method
        captured["path"] = request.url.path
        captured["json"] = __import__("json").loads(request.content)
        return httpx.Response(200, json={
            "deployment_id": "deepseek", "provider_id": "deepseek",
            "model": "deepseek-chat", "status": "reachable", "reason_code": "ok",
            "probe_mode": "external_connectivity_canary", "egress_decision": "allow",
            "synthetic_payload": True, "patient_data_sent": False,
            "expected_token_matched": True, "latency_ms": 25,
            "usage": {"input_tokens": 31, "output_tokens": 4},
            "cost": {"amount": 0.000006, "currency": "CNY",
                     "billing_authoritative": False,
                     "source": "provider_usage_pricing_estimate"},
            "request_cost_cap_cny": 0.01, "estimated_max_cost_cny": 0.000146,
            "checked_at": "2026-08-21T00:00:00Z",
        })

    client = iCoDerClient(
        iCoDerConfig(base_url="https://api.cn.icoder.cloud", access_token="token")
    )
    client.http.close()
    client.http = httpx.Client(
        base_url=client.base_url,
        headers={"Authorization": "Bearer token"},
        transport=httpx.MockTransport(handler),
    )
    try:
        result = client.models.live_canary("deepseek", max_cost_cny=0.01)
    finally:
        client.close()

    assert captured == {
        "method": "POST", "path": "/api/v1/model-catalog/live-canary",
        "json": {
            "deployment_id": "deepseek", "acknowledge_external_call": True,
            "purpose": "connectivity_only_no_patient_data", "max_cost_cny": 0.01,
        },
    }
    assert result["patient_data_sent"] is False
    assert result["cost"]["billing_authoritative"] is False
