import json

import httpx
import pytest

from icoder_sdk import (
    A2AProtocolError,
    A2ATransportError,
    iCoDerClient,
    iCoDerConfig,
)


def _client(handler):
    client = iCoDerClient(
        iCoDerConfig(base_url="https://api.cn.icoder.cloud", access_token="token")
    )
    client.http.close()
    client.http = httpx.Client(
        base_url=client.base_url,
        headers={"Authorization": "Bearer token"},
        transport=httpx.MockTransport(handler),
    )
    return client


def test_a2a_multi_turn_get_and_delete_contract():
    calls = []
    context_id = "11111111-1111-4111-8111-111111111111"

    def handler(request):
        body = json.loads(request.content) if request.content else None
        calls.append((request, body))
        if request.method == "POST":
            return httpx.Response(200, json={
                "jsonrpc": "2.0",
                "id": body["id"],
                "result": {
                    "kind": "message",
                    "role": "agent",
                    "messageId": f"agent-{len(calls)}",
                    "contextId": context_id,
                    "parts": [],
                    "metadata": {},
                },
            })
        if request.method == "GET":
            return httpx.Response(200, json={"id": context_id, "items": [{}, {}, {}, {}]})
        return httpx.Response(200, json={
            "jsonrpc": "2.0",
            "id": None,
            "result": {
                "kind": "context",
                "contextId": context_id,
                "deleted": True,
                "reason": "user_requested",
            },
        })

    client = _client(handler)
    try:
        first = client.a2a.message_send("note-completeness-agent", "first")
        second = client.a2a.message_send(
            "note-completeness-agent", "second", context_id=first["contextId"]
        )
        context = client.a2a.get_context("note-completeness-agent", context_id)
        deleted = client.a2a.delete_context(context_id)
    finally:
        client.close()

    assert second["contextId"] == context_id
    assert len(context["items"]) == 4
    assert deleted["deleted"] is True
    assert all(request.headers["A2A-Protocol-Version"] == "0.3" for request, _ in calls)
    assert calls[1][1]["params"]["message"]["contextId"] == context_id


def test_a2a_protocol_error_does_not_retain_details():
    def handler(_request):
        return httpx.Response(500, json={
            "jsonrpc": "2.0",
            "id": "rpc-1",
            "error": {
                "code": -32603,
                "message": "Internal error",
                "data": {
                    "a2a_error_code": "PLANNING_FAILED",
                    "details": "patient-secret-value",
                },
            },
        })

    client = _client(handler)
    try:
        with pytest.raises(A2AProtocolError) as raised:
            client.a2a.message_send("note-completeness-agent", "synthetic")
    finally:
        client.close()

    assert raised.value.jsonrpc_code == -32603
    assert raised.value.a2a_error_code == "PLANNING_FAILED"
    assert "patient-secret-value" not in str(raised.value)


def test_a2a_transport_error_does_not_retain_request_or_body():
    def handler(_request):
        return httpx.Response(500, json={"detail": "patient-secret-value"})

    client = _client(handler)
    try:
        with pytest.raises(A2ATransportError) as raised:
            client.a2a.message_send("note-completeness-agent", "synthetic")
    finally:
        client.close()

    assert raised.value.http_status == 500
    assert "patient-secret-value" not in str(raised.value)
    assert not hasattr(raised.value, "request")
    assert not hasattr(raised.value, "response")


def test_a2a_v1_async_task_poll_list_cancel_and_subscription_resume():
    calls = []
    task_reads = 0

    def handler(request):
        nonlocal task_reads
        body = json.loads(request.content) if request.content else None
        calls.append((request, body))
        path = request.url.path
        if path.endswith("/message:send"):
            return httpx.Response(200, json={
                "task": {
                    "id": "task-1",
                    "contextId": "context-1",
                    "status": {"state": "TASK_STATE_SUBMITTED"},
                    "artifacts": [],
                    "history": [],
                    "metadata": {},
                }
            })
        if path.endswith("/tasks/task-1:subscribe"):
            return httpx.Response(
                200,
                headers={"content-type": "text/event-stream"},
                text=(
                    "id: 2\nevent: task\n"
                    'data: {"eventId":"2","eventType":"working","task":{}}\n\n'
                    "id: 3\nevent: task\n"
                    'data: {"eventId":"3","eventType":"completed","task":{}}\n\n'
                ),
            )
        if path.endswith("/tasks/task-1:cancel"):
            return httpx.Response(200, json={
                "id": "task-1",
                "status": {"state": "TASK_STATE_CANCELED"},
            })
        if path.endswith("/tasks/task-1"):
            task_reads += 1
            state = "TASK_STATE_WORKING" if task_reads == 1 else "TASK_STATE_COMPLETED"
            return httpx.Response(200, json={
                "id": "task-1",
                "status": {"state": state},
                "artifacts": [],
            })
        if path.endswith("/tasks"):
            return httpx.Response(200, json={
                "tasks": [{"id": "task-1"}],
                "pageSize": 10,
                "totalSize": 1,
                "nextPageToken": "",
            })
        raise AssertionError(path)

    client = _client(handler)
    try:
        submitted = client.a2a.message_send_v1(
            "note-completeness-agent",
            "safe note",
            message_id="message-1",
            return_immediately=True,
        )["task"]
        completed = client.a2a.wait_task_v1(
            "note-completeness-agent",
            submitted["id"],
            timeout=1,
            poll_interval=0.001,
        )
        listed = client.a2a.list_tasks_v1(
            "note-completeness-agent",
            page_size=10,
            include_artifacts=True,
        )
        events = list(client.a2a.subscribe_task_v1(
            "note-completeness-agent",
            "task-1",
            after_sequence=1,
            last_event_id="1",
        ))
        canceled = client.a2a.cancel_task_v1(
            "note-completeness-agent",
            "task-1",
        )
    finally:
        client.close()

    assert completed["status"]["state"] == "TASK_STATE_COMPLETED"
    assert listed["totalSize"] == 1
    assert [event["eventType"] for event in events] == ["working", "completed"]
    assert canceled["status"]["state"] == "TASK_STATE_CANCELED"
    assert all(request.headers["A2A-Version"] == "1.0" for request, _ in calls)
    send_call = next(item for item in calls if item[0].url.path.endswith("message:send"))
    assert send_call[1]["configuration"]["returnImmediately"] is True
    subscribe_call = next(item for item in calls if item[0].url.path.endswith(":subscribe"))
    assert subscribe_call[0].headers["Last-Event-ID"] == "1"
    assert subscribe_call[0].url.params["afterSequence"] == "1"


def test_a2a_v1_error_extracts_only_stable_reason():
    def handler(_request):
        return httpx.Response(404, json={
            "error": {
                "code": 404,
                "status": "NOT_FOUND",
                "message": "Task not found",
                "details": [{
                    "@type": "type.googleapis.com/google.rpc.ErrorInfo",
                    "reason": "TASK_NOT_FOUND",
                    "metadata": {"secret": "patient-secret-value"},
                }],
            }
        })

    client = _client(handler)
    try:
        with pytest.raises(A2AProtocolError) as raised:
            client.a2a.get_task_v1("note-completeness-agent", "missing")
    finally:
        client.close()

    assert raised.value.a2a_error_code == "TASK_NOT_FOUND"
    assert "patient-secret-value" not in str(raised.value)


def test_agentic_trace_export_and_feedback_contract():
    calls = []

    def handler(request):
        body = json.loads(request.content) if request.content else None
        calls.append((request, body))
        if request.url.path.endswith("/trace"):
            return httpx.Response(200, json={
                "traces": [], "nextPageToken": None, "totalSize": None,
            })
        if request.method == "POST":
            return httpx.Response(201, json={
                "id": "fb-1", "taskId": "task-1",
                "rating": body["rating"], "normalizedScore": 1.0,
                "labels": body["labels"], "reason": None,
                "createdAt": "2026-08-22T00:00:00Z",
                "target": body.get("target"),
            })
        if request.method == "GET":
            return httpx.Response(200, json={"feedbacks": []})
        return httpx.Response(204)

    client = _client(handler)
    try:
        trace = client.a2a.export_context_traces("context/one", page_size=20)
        feedback = client.a2a.submit_task_feedback("context/one", "task/one", {
            "rating": {"scale": "binary", "value": 1},
            "labels": ["helpful"],
            "target": {"messageId": "message-1"},
        })
        listed = client.a2a.list_task_feedback("context/one", "task/one")
        deleted = client.a2a.delete_task_feedback("context/one", "task/one")
    finally:
        client.close()

    assert trace["traces"] == []
    assert feedback["id"] == "fb-1"
    assert listed == {"feedbacks": []}
    assert deleted is None
    assert calls[0][0].url.params["pageSize"] == "20"
    assert calls[1][1]["target"]["messageId"] == "message-1"
    assert calls[-1][0].method == "DELETE"


def test_agentic_agent_usage_contract():
    captured = []

    def handler(request):
        captured.append(request)
        return httpx.Response(200, json={
            "granularity": "day",
            "from": "2026-08-01T00:00:00Z",
            "to": "2026-08-03T00:00:00Z",
            "totals": {"invocations": 3, "uniqueContexts": 2},
            "buckets": [{
                "periodStart": "2026-08-01T00:00:00Z",
                "periodEnd": "2026-08-02T00:00:00Z",
                "invocations": 3,
                "uniqueContexts": 2,
            }],
        })

    client = _client(handler)
    try:
        usage = client.a2a.get_agent_usage(
            "agent/one",
            from_time="2026-08-01T00:00:00Z",
            to_time="2026-08-03T00:00:00Z",
            granularity="hour",
        )
        with pytest.raises(ValueError, match="granularity"):
            client.a2a.get_agent_usage("agent", granularity="month")
    finally:
        client.close()

    assert usage["granularity"] == "day"
    assert usage["totals"]["uniqueContexts"] == 2
    assert captured[0].url.raw_path.split(b"?", 1)[0].endswith(
        b"/agents/agent%2Fone/usage"
    )
    assert captured[0].url.params["from"] == "2026-08-01T00:00:00Z"
    assert captured[0].url.params["granularity"] == "hour"


def test_a2a_v1_agent_card_discovery_contract():
    captured = []

    def handler(request):
        captured.append(request)
        return httpx.Response(200, json={
            "name": "Tenant Agent",
            "description": "Scoped Agent",
            "version": "1.0.0",
            "supportedInterfaces": [{
                "url": "https://api.cn.icoder.cloud/a2a",
                "protocolBinding": "JSONRPC",
                "protocolVersion": "1.0",
            }],
            "capabilities": {"streaming": True, "pushNotifications": False},
            "defaultInputModes": ["text/plain"],
            "defaultOutputModes": ["application/json"],
            "skills": [{
                "id": "run", "name": "Run", "description": "Run Agent", "tags": ["a2a"],
            }],
        })

    client = _client(handler)
    try:
        card = client.a2a.get_agent_card("agent/one")
    finally:
        client.close()

    assert card["supportedInterfaces"][0]["protocolVersion"] == "1.0"
    assert captured[0].url.raw_path.decode() == (
        "/api/v2/agentic/agents/agent%2Fone/.well-known/agent-card.json"
    )
    assert captured[0].headers["A2A-Version"] == "1.0"
