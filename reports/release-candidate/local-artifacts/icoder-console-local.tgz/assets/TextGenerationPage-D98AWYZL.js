import{r as n,j as e,B as Le,a0 as Ie,_ as Xe,V as De,x as Q,a1 as Me,a2 as Oe,a3 as Z,J as ee,a5 as Re,X as ze}from"./vendor-yFWQPn5j.js";import{b as $e,u as He,W as Be,h as Ge,S as Je,E as Ue,C as Ve}from"./index-Cuq-EtYZ.js";const N=2e5,$=1024*1024,H=100,se=64,re=256,ne=2e3,qe=64,ae=2e4;function oe(l){if(!l||typeof l!="object")return!1;const a=l;return typeof a.key=="string"&&a.key.length>0&&a.key.length<=se&&typeof a.name=="string"&&a.name.length>0&&a.name.length<=re&&typeof a.desc=="string"&&a.desc.length<=ne&&typeof a.category=="string"&&a.category.length>0&&a.category.length<=qe&&typeof a.sample=="string"&&a.sample.length<=ae}const z=[{key:"discharge_summary",name:"出院小结",desc:"标准出院小结，包含入院情况、诊疗经过、出院诊断、出院医嘱",category:"住院",sample:`患者，男，65岁，因"反复胸闷、心悸3年，加重1周"入院。
既往史：高血压病史10年，口服氨氯地平5mg qd；2型糖尿病史5年，口服二甲双胍0.5g tid。
入院查体：T 36.5°C，P 78次/分，R 18次/分，BP 138/86mmHg。双肺呼吸音清，未闻及干湿啰音。心率78次/分，律齐，各瓣膜听诊区未闻及病理性杂音。
辅助检查：冠脉造影示LAD中段狭窄75%。
诊疗经过：行PCI术，于LAD中段植入药物洗脱支架1枚，术后抗血小板、调脂稳定斑块等治疗。
出院诊断：1. 冠状动脉粥样硬化性心脏病 不稳定型心绞痛 PCI术后
出院医嘱：1. 低盐低脂饮食，适当运动；2. 规律服药，定期门诊复查；3. 不适随诊。`},{key:"admission_record",name:"入院记录",desc:"完整入院记录，含主诉、现病史、既往史、体格检查、初步诊断",category:"住院",sample:`主诉：腰痛4个月余。
现病史：患者4月前无明显诱因出现腰痛，呈持续性钝痛，久坐久站后加重，卧床休息后稍缓解。近1月疼痛明显加重，VAS评分7分。否认外伤史。
既往史：高血压病史5年，口服硝苯地平控制可。否认糖尿病史，否认肝炎、结核等传染病史。否认手术外伤史，否认药物过敏史。
体格检查：T 36.3°C，P 72次/分，R 18次/分，BP 132/82mmHg。脊柱生理曲度改变，T7-L2棘突压痛和叩击痛明显，双下肢无水肿，双侧膝腱反射对称存在。
辅助检查：胸腰椎MRI示：T7、T9、T12及L2椎体考虑为新鲜压缩骨折。
初步诊断：1. 腰椎压缩性骨折 2. 胸椎压缩性骨折 3. 重度骨质疏松症 4. 高血压病`},{key:"progress_note",name:"日常病程记录",desc:"SOAP格式病程记录：主观、客观、评估、计划",category:"住院",sample:`S（主观）：患者诉腰痛较前缓解，VAS评分3-4分，可自行翻身，无下肢放射痛及麻木感。
O（客观）：T 36.2°C，P 70次/分，R 18次/分，BP 130/80mmHg。腰部敷料干燥，无渗血渗液，双下肢感觉运动正常。
A（评估）：术后恢复良好，疼痛明显缓解，生命体征平稳，无并发症征象。
P（计划）：1. 继续抗骨质疏松治疗；2. 指导功能锻炼；3. 明日复查X光片评估骨水泥位置。`},{key:"preop_discussion",name:"术前讨论记录",desc:"术前讨论：手术指征、手术方案、风险评估、替代方案",category:"手术",sample:`讨论时间：2026年5月9日
主持人：李主任（骨科主任医师）
参加人员：张主治医师、王住院医师、麻醉科刘医师
手术指征：患者L4/5椎间盘突出，左侧神经根受压，保守治疗3月无效，疼痛影响日常生活。
手术方案：拟行L4/5椎间盘髓核摘除术（PLIF）。
风险评估：ASA II级，心肺功能可耐受手术，术中出血风险可控。
替代方案：已向患者说明保守治疗及微创方案，患者选择手术治疗。
术前准备：备血2U，预防性抗生素皮试已做。`},{key:"operation_record",name:"手术记录",desc:"手术经过、术中所见、标本送检、术中特殊情况",category:"手术",sample:`手术名称：T7、T9、T12、L2经皮穿刺脊柱后凸成形术
手术日期：2026年5月9日
麻醉方式：全麻
手术经过：患者全麻后取俯卧位，C臂机定位T7、T9、T12、L2椎体双侧椎弓根。常规消毒铺巾后，穿刺针经皮穿刺进入椎弓根，球囊扩张恢复椎体高度，注入骨水泥。术中X光透视骨水泥分布良好，无渗漏。
术中所见：椎体压缩约30-40%，骨水泥填充满意。
术中出血：约50ml。
标本送检：无。
术者：李主任 助手：张主治医师`},{key:"referral_letter",name:"转诊信",desc:"转诊至其他科室或医院，含转诊原因、已有检查、治疗建议",category:"门诊",sample:`转诊科室：心血管内科
转诊原因：患者因"反复胸闷、胸痛2月"在我科就诊，心电图示ST-T改变，运动平板试验阳性，考虑冠心病可能，需进一步冠脉造影明确诊断。
已有检查：血常规、心肌酶谱正常；心电图示V4-V6导联ST段下移0.1mV；心脏彩超示左室舒张功能减退。
当前用药：阿司匹林100mg qd，阿托伐他汀20mg qn。
建议：请贵科协助行冠脉造影检查，明确冠脉病变情况。`},{key:"outpatient_note",name:"门诊就诊记录",desc:"通用门诊就诊记录，含主诉、查体、诊断、处理意见",category:"门诊",sample:`主诉：咳嗽、咳痰3天。
现病史：3天前受凉后出现咳嗽，咳黄色黏痰，无发热，无胸闷气促。
查体：T 36.8°C，咽部充血，双肺呼吸音粗，未闻及干湿啰音。
诊断：急性支气管炎
处理意见：1. 头孢呋辛酯 0.25g bid ×5天；2. 氨溴索30mg tid；3. 多饮水，注意休息；4. 如症状加重随时复诊。`},{key:"emergency_note",name:"急诊记录",desc:"急诊就诊记录：来院方式、生命体征、急诊处理、离院方式",category:"急诊",sample:`来院方式：120急救车送入。
主诉：突发胸痛2小时。
生命体征：T 36.5°C，P 96次/分，R 22次/分，BP 160/95mmHg，SpO2 96%。
急诊查体：神清，痛苦貌，双肺呼吸音清，心率96次/分，律齐。
急诊心电图：V1-V4导联ST段抬高0.2-0.4mV。
急诊处理：1. 吸氧；2. 阿司匹林300mg嚼服；3. 氯吡格雷600mg口服；4. 硝酸甘油0.5mg舌下含服；5. 通知心内科急会诊。
离院方式：转CCU住院。`},{key:"consultation_record",name:"会诊记录",desc:"科间会诊申请与意见：会诊目的、病史摘要、会诊意见",category:"住院",sample:`会诊申请科室：骨科 申请会诊科室：心内科
会诊目的：患者拟行腰椎手术，既往冠心病史，请评估手术风险。
病史摘要：患者，男，68岁，因腰椎间盘突出症拟行手术治疗。既往冠心病史3年，曾行冠脉支架植入术（LAD 1枚），目前口服阿司匹林+氯吡格雷双抗治疗中。
会诊意见：患者冠心病 PCI术后，心功能I级，可耐受手术。建议：1. 术前停用双抗5天，改用低分子肝素桥接；2. 术中监测心电图和血压；3. 术后24小时恢复双抗治疗。
会诊医师：刘主任医师`},{key:"nursing_note",name:"护理记录",desc:"护理观察记录：生命体征、护理措施、病情变化、交班要点",category:"护理",sample:`生命体征：T 36.5°C，P 78次/分，R 18次/分，BP 135/82mmHg，SpO2 98%。
护理措施：1. 术后卧床休息，轴线翻身q2h；2. 腰部伤口敷料观察，无渗血渗液；3. 双下肢感觉运动正常，足趾活动自如；4. 指导踝泵运动，预防DVT。
病情变化：患者诉切口轻度疼痛，NRS评分3分，已通知医师。
交班要点：1. 注意观察双下肢感觉运动；2. 指导功能锻炼循序渐进；3. 明日拔除尿管。`},{key:"patient_summary",name:"患者摘要",desc:"面向非医学专业人士的患者就诊摘要，通俗易懂",category:"通用",sample:`就诊日期：2026年5月9日
就诊科室：骨科
您此次就诊的主要原因是：腰痛4个多月，最近1个月加重。
经过MRI等检查，医生发现您的胸椎和腰椎有4个椎体存在压缩性骨折，同时伴有重度骨质疏松和高血压。
医生为您进行了微创手术（椎体成形术），手术很顺利。术后您的腰痛明显缓解。
您出院后需要注意：1. 避免弯腰、搬重物；2. 按时服用降压药和抗骨质疏松药物；3. 定期到骨科门诊复查；4. 如出现新的腰背痛或下肢麻木无力，请及时就医。`},{key:"surgery_consent",name:"手术知情同意书",desc:"含手术名称、风险、并发症、替代方案，需医患双方签字",category:"手术",sample:`患者姓名：XXX 性别：男 年龄：65岁 病历号：XXXXXX
疾病诊断：冠状动脉粥样硬化性心脏病 三支病变
建议手术名称：冠状动脉旁路移植术（CABG）
手术风险及并发症：1. 麻醉意外；2. 术中出血，可能需要输血；3. 术后感染（切口感染、肺部感染等）；4. 心律失常、心肌梗死；5. 脑卒中；6. 肾功能损伤；7. 桥血管闭塞需再次手术；8. 死亡风险约1-2%。
替代医疗方案：1. 药物保守治疗；2. PCI支架植入术；3. 杂交手术。
上述情况已向患者及家属详细说明，患者及家属表示理解并同意手术。
患者签名：XXX 家属签名：XXX 医师签名：XXX
日期：2026年5月10日`},{key:"nursing_handoff",name:"护理交班报告",desc:"结构化交班：患者基本信息、病情变化、重点观察、待办事项",category:"护理",sample:`交班日期：2026年5月9日 班次：白班→夜班
患者：张三，男，65岁，骨科6床，住院号123456
诊断：腰椎压缩性骨折 PKP术后第2天
生命体征：T 36.3°C，P 72次/分，R 18次/分，BP 132/82mmHg，SpO2 98%
本班病情变化：患者诉腰部切口疼痛NRS 3分，已予曲马多50mg肌注后缓解。下午自行排尿1次，量约400ml。
重点观察：1. 双下肢感觉运动q2h；2. 切口敷料有无渗血；3. 疼痛评分
待办事项：1. 明晨抽血复查电解质；2. 指导佩戴腰围下床活动；3. 拔除尿管
交班护士：李护士 接班护士：王护士`},{key:"discharge_education",name:"出院健康宣教",desc:"出院指导：用药、饮食、活动、复查、危险信号",category:"护理",sample:`患者：王五，诊断：2型糖尿病，住院号：789012
一、用药指导
1. 二甲双胍0.5g 每日2次（早晚餐后口服）
2. 甘精胰岛素10U 每晚22:00皮下注射
3. 请勿自行停药或调整剂量
二、饮食指导
1. 低糖、低脂、适量优质蛋白饮食；2. 定时定量，少食多餐；3. 每日食盐<6g；4. 戒烟限酒
三、活动指导
1. 每日步行30分钟；2. 避免空腹运动；3. 运动前后监测血糖
四、复查计划
1. 出院后1周到内分泌科门诊复查；2. 每3个月查糖化血红蛋白；3. 每年查眼底、肾功能
五、危险信号（出现以下情况立即就医）
1. 血糖<3.9mmol/L或>16.7mmol/L；2. 意识模糊、恶心呕吐；3. 足部破溃感染`},{key:"medication_reconciliation",name:"用药重整记录",desc:"入院/转科/出院时用药核对与调整，减少用药差错",category:"住院",sample:`重整节点：入院重整
患者：李四，男，72岁
入院前用药：
1. 氨氯地平5mg qd（降压）
2. 阿司匹林100mg qd（抗血小板）
3. 二甲双胍0.5g tid（降糖）
4. 布洛芬200mg tid（关节疼痛，自行购买）
入院后调整：
1. 氨氯地平5mg qd -- 继续
2. 阿司匹林100mg qd -- 继续
3. 二甲双胍0.5g tid -- 继续，加测HbA1c
4. 布洛芬 -- 停用（可能影响肾功能，改为对乙酰氨基酚必要时）
新增：
5. 胰岛素（根据血糖调整）
6. 奥美拉唑20mg qd（护胃）
药师审核：张药师 医师确认：刘主治`},{key:"imaging_report",name:"影像检查报告",desc:"CT/MRI/X光检查所见、影像诊断、建议",category:"检查",sample:`检查项目：胸部CT平扫
检查日期：2026年5月9日
检查所见：双肺纹理增粗、紊乱，右肺上叶后段见片状高密度影，边界模糊，大小约3.2×2.8cm，其内可见支气管充气征。双肺散在多发小结节影，直径约3-5mm。纵隔居中，纵隔内未见明显肿大淋巴结。双侧胸腔无积液。
影像诊断：
1. 右肺上叶后段炎症，考虑感染性病变可能性大，建议治疗后复查
2. 双肺多发小结节，建议随访观察
3. 慢性支气管炎改变
报告医师：赵医生 审核医师：钱主任`},{key:"pathology_report",name:"病理检查报告",desc:"大体所见、镜下所见、病理诊断、免疫组化",category:"检查",sample:`送检标本：右肺上叶切除标本
大体所见：肺叶大小15×10×5cm，切面见一灰白色结节，大小3.0×2.5×2.0cm，边界不清，质地硬，距支气管切缘2.0cm。
镜下所见：肿瘤细胞呈腺管状、乳头状排列，细胞异型性明显，核分裂象易见。肿瘤侵犯脏层胸膜。支气管切缘未见肿瘤。淋巴结：第7组（0/3），第10组（1/5）见肿瘤转移。
病理诊断：
1. 右肺上叶中分化腺癌，腺泡型为主，部分乳头型
2. 肿瘤大小3.0×2.5×2.0cm
3. 脏层胸膜受侵（+）
4. 支气管切缘（-）
5. 淋巴结转移：第10组（1/5）
6. pTNM分期：pT2aN1M0，IIB期
免疫组化：TTF-1(+)，Napsin A(+)，CK7(+)，CK5/6(-)，P40(-)，Ki-67(30%+)
报告日期：2026年5月12日`},{key:"icu_daily_note",name:"ICU日常记录",desc:"ICU每日评估：器官功能、液体管理、感染指标、镇静评分",category:"住院",sample:`日期：2026年5月10日 ICU第3天
意识状态：镇静状态，RASS评分-2，GCS评分E3VTM5
呼吸：呼吸机辅助通气，模式SIMV+PS，FiO2 0.35，PEEP 5cmH2O，RR 16次/分，SpO2 97%
循环：HR 88次/分，BP 115/70mmHg（去甲肾上腺素0.05μg/kg/min维持），CVP 8mmHg
24h入量：晶体1500ml + 胶体500ml + 肠内营养500ml = 2500ml
24h出量：尿量1200ml + 胃管引流100ml + 伤口引流50ml = 1350ml
平衡：+1150ml
感染指标：WBC 12.3×10⁹/L，PCT 1.8ng/mL，CRP 86mg/L
抗生素：头孢哌酮舒巴坦3.0g q8h ivgtt（第3天）
计划：1. 继续目前呼吸机支持，评估脱机条件；2. 维持液体平衡；3. 明日复查PCT。`},{key:"death_summary",name:"死亡记录",desc:"入院情况、诊疗经过、死亡原因、死亡诊断",category:"住院",sample:`患者：赵六，男，78岁，住院号：345678
入院日期：2026年5月1日 死亡日期：2026年5月15日 住院天数：15天
入院情况：因突发胸痛2小时入院。既往冠心病史5年，2型糖尿病史10年。
诊疗经过：入院后心电图示急性广泛前壁心肌梗死，急诊行PCI术，于LAD植入支架1枚。术后第5天出现心源性休克，予IABP辅助，多巴胺+去甲肾上腺素维持血压。第10天出现急性肾损伤，予CRRT治疗。第14天出现多器官功能衰竭。
死亡原因：1. 急性心肌梗死；2. 心源性休克；3. 多器官功能衰竭
死亡诊断：1. 冠状动脉粥样硬化性心脏病 急性广泛前壁心肌梗死 PCI术后；2. 心源性休克；3. 急性肾损伤；4. 2型糖尿病
家属告知：已通知家属，家属表示理解。
记录医师：孙主任`}];function Ke(l){if(!l)return z;try{const a=JSON.parse(l);return Array.isArray(a)&&a.length<=H&&a.every(oe)?a:z}catch{return z}}function Fe(l,a){if(a==="text"){if(!l.trim())throw new Error("文本输入不能为空。");if(l.length>N)throw new Error(`文本输入不能超过 ${N} 个字符。`);return[{type:"text",text:l.trim()}]}if(new TextEncoder().encode(l).byteLength>$)throw new Error(`JSON 输入不能超过 ${$} 字节。`);let c;try{c=JSON.parse(l)}catch{throw new Error("JSON 输入格式无效。")}const g=c&&typeof c=="object"&&!Array.isArray(c)&&Array.isArray(c.context)?c.context:Array.isArray(c)?c:[c];if(!g.length)throw new Error("JSON context 不能为空。");if(g.length>64)throw new Error("JSON context 不能超过 64 个项目。");const p=[];let h=0;for(const f of g){if(!f||typeof f!="object")throw new Error("JSON context 必须是对象。");const r=f;if(r.type==="text"&&typeof r.text=="string"&&r.text.trim()){if(r.text.length>N)throw new Error("单个 text context 过长。");h+=r.text.length,p.push({type:"text",text:r.text.trim()})}else if(r.type==="facts"&&Array.isArray(r.facts)&&r.facts.length&&r.facts.length<=2e3&&r.facts.every(s=>s&&typeof s.text=="string"&&s.text.trim()&&s.text.length<=4e3&&(s.group===void 0||typeof s.group=="string"&&s.group.length<=128)))h+=r.facts.reduce((s,d)=>s+d.text.length,0),p.push({type:"facts",facts:r.facts.map(s=>({text:s.text.trim(),...typeof s.group=="string"&&s.group?{group:s.group}:{}}))});else if(r.type==="transcript"&&r.transcript&&Array.isArray(r.transcript.transcripts)&&r.transcript.transcripts.length&&r.transcript.transcripts.length<=2e3&&r.transcript.transcripts.every(s=>s&&typeof s.text=="string"&&s.text.trim()&&s.text.length<=4e3&&["channel","participant","speakerId","start","end"].every(d=>s[d]===void 0||Number.isInteger(s[d])&&s[d]>=0)))h+=r.transcript.transcripts.reduce((s,d)=>s+d.text.length,0),p.push({type:"transcript",transcript:{transcripts:r.transcript.transcripts.map(s=>({text:s.text.trim(),...["channel","participant","speakerId","start","end"].reduce((d,y)=>(Number.isInteger(s[y])&&(d[y]=s[y]),d),{})})),...r.transcript.metadata&&typeof r.transcript.metadata=="object"&&!Array.isArray(r.transcript.metadata)?{metadata:r.transcript.metadata}:{}}});else throw new Error("JSON context 仅支持非空 text、facts 或 transcript。");if(h>N)throw new Error(`context 文本总量不能超过 ${N} 个字符。`)}if(!p.length)throw new Error("JSON context 不能为空。");return p}const We=[{key:"text",label:"文本"},{key:"json",label:"JSON"}],Ye=[{code:"zh-CN",label:"简体中文"},{code:"en-US",label:"英文 (美国)"}],te=["全部","住院","门诊","手术","急诊","护理","通用"];function et(){const l=$e(t=>t.locale),a=He(),[c,g]=n.useState(()=>Ke(localStorage.getItem("icoder-textgen-templates"))),[p,h]=n.useState(""),[f,r]=n.useState(""),[s,d]=n.useState(!1),[y,B]=n.useState(""),[G,T]=n.useState(""),[k,J]=n.useState("text"),[m,U]=n.useState(""),[v,le]=n.useState("zh-CN"),[_,ce]=n.useState("standard"),[ie,C]=n.useState(!1),[u,de]=n.useState(""),[S,me]=n.useState("全部"),[V,q]=n.useState(!1),[pe,L]=n.useState([]),[xe,ue]=n.useState(0),[w,K]=n.useState(null),[ge,b]=n.useState(!1),[E,I]=n.useState(""),[A,X]=n.useState(""),[F,D]=n.useState(""),[W,M]=n.useState("住院"),[Y,O]=n.useState(""),[he,R]=n.useState(null);n.useEffect(()=>{try{localStorage.setItem("icoder-textgen-templates",JSON.stringify(c)),T("")}catch{T("浏览器存储空间不足，模板变更仅在当前页面有效。")}},[c]),c.filter(t=>!(S!=="全部"&&t.category!==S||u&&!t.name.includes(u)&&!t.key.includes(u)&&!t.desc.includes(u)));const i=c.find(t=>t.key===m),fe=async()=>{if(!(!p.trim()||!m||!i)){d(!0),B(""),r(""),L(t=>[...t.slice(-50),{type:"generate_start",data:{template:m,inputLength:p.length},timestamp:new Date().toLocaleTimeString(l,{hour12:!1})}]);try{const t=_==="strict"?"严格核对原文，缺失信息明确标注“未提供”，不得推断。":_==="draft"?"生成供临床人员复核的简洁草稿。":"生成结构完整、措辞专业的临床文书。",o=await Ge.generateDynamic({outputLanguage:v,context:Fe(p,k),dynamicTemplate:{name:i.name,generation:{instructions:{prompt:`${i.desc} ${t} 仅使用输入中有依据的信息。`},sections:[{heading:i.name,instructions:{contentPrompt:`${i.desc} ${t}`,writingStylePrompt:"使用符合中国临床病历书写习惯的专业中文；输出语言以请求参数为准。",miscPrompt:"不得编造诊断、用药、检查结果或患者身份信息。"},outputSchema:{type:"string"}}]}}});if(o.headers["x-corti-retention-policy"]!=="acknowledged")throw new Error("服务器未确认零留存策略，结果已丢弃。");const x=Object.values(o.data.document.stringDocument).filter(j=>typeof j=="string"&&j.trim()).join(`

`);if(!x)throw new Error("服务未返回可显示的文书内容。");const P=o.data.usageInfo.creditsConsumed;r(x),ue(j=>j+P),L(j=>[...j.slice(-50),{type:"generate_complete",data:{template:m,outputLength:x.length,retention:"none"},timestamp:new Date().toLocaleTimeString(l,{hour12:!1}),credits:P}])}catch(t){const o=t?.response?.data?.detail,x=typeof o=="string"?o:o?.detail||o?.reason||t.message||"生成失败";B(x),L(P=>[...P.slice(-50),{type:"generate_error",data:{error:x,template:m},timestamp:new Date().toLocaleTimeString(l,{hour12:!1})}])}finally{d(!1)}}},ye=()=>{i&&(h(i.sample),J("text"))},be=()=>{if(c.length>=H){T(`最多可保存 ${H} 个模板，请先删除不再使用的模板。`);return}K(null),I(""),X(""),D(""),M("住院"),O(""),b(!0)},je=t=>{K(t),I(t.key),X(t.name),D(t.desc),M(t.category),O(t.sample),b(!0)},Ne=()=>{if(!E.trim()||!A.trim())return;const t={key:E.trim().replace(/\s+/g,"_").toLowerCase(),name:A.trim(),desc:F.trim(),category:W,sample:Y};if(!oe(t)){T("模板字段为空或超过长度限制，请缩短后重试。");return}g(w?o=>o.map(x=>x.key===w.key?t:x):o=>[...o,t]),b(!1)},ve=t=>{g(o=>o.filter(x=>x.key!==t)),m===t&&U(""),R(null)},Ce=`import iCoDer from "@icoder/sdk";
const client = new iCoDer({
  baseURL: "https://api.cn.icoder.cloud",
  auth: { accessToken: "<access-token>" },
});
const result = await client.textGen.generate("临床文本...", {
  template: "${i?.name||"出院小结"}",
  outputLanguage: "${v}",
});`,Se=`from icoder_sdk import iCoDerClient, iCoDerConfig

client = iCoDerClient(iCoDerConfig(
    base_url="https://api.cn.icoder.cloud",
    access_token="<access-token>",
))

result = client.textgen.generate(
    "临床文本...",
    template="${i?.name||"出院小结"}",
    output_language="${v}",
)
print(result["output"])`,Te=`{
  "outputLanguage": "${v}",
  "context": [{ "type": "text", "text": "临床文本..." }],
  "dynamicTemplate": {
    "name": "${i?.name||"出院小结"}",
    "generation": {
      "instructions": { "prompt": "仅使用输入中有依据的信息生成临床文书。" },
      "sections": [{
        "heading": "${i?.name||"出院小结"}",
        "instructions": { "contentPrompt": "${i?.desc||"生成临床文书"}" },
        "outputSchema": { "type": "string" }
      }]
    }
  }
}`,ke=e.jsxs("div",{className:"flex flex-col",children:[e.jsxs("div",{className:"border-b border-border/20",children:[e.jsxs("div",{className:"flex items-center gap-2 px-4 pt-4 pb-2",children:[e.jsx("div",{className:"w-1 h-4 rounded-full bg-primary/40"}),e.jsx("h3",{className:"font-medium text-xs text-muted-foreground",children:"模板"})]}),e.jsxs("div",{className:"px-4 pb-4",children:[e.jsxs("button",{onClick:()=>C(!0),className:"w-full py-2 rounded-lg border border-border hover:bg-accent transition-colors text-sm flex items-center justify-center gap-2",children:[e.jsx(Le,{size:14})," 选择模板"]}),m&&e.jsxs("p",{className:"text-xs text-center text-muted-foreground mt-2",children:["当前: ",i?.name]})]})]}),e.jsxs("div",{className:"border-b border-border/20",children:[e.jsxs("div",{className:"flex items-center gap-2 px-4 pt-4 pb-2",children:[e.jsx("div",{className:"w-1 h-4 rounded-full bg-primary/40"}),e.jsx("h3",{className:"font-medium text-xs text-muted-foreground",children:"文书设置"})]}),e.jsxs("div",{className:"flex flex-col gap-3 px-4 pb-4 pt-1",children:[e.jsxs("div",{className:"flex items-center justify-between gap-4 min-h-[32px]",children:[e.jsx("span",{className:"text-sm text-foreground/80",children:"输出语言"}),e.jsx("select",{value:v,onChange:t=>le(t.target.value),className:"h-8 text-xs border border-input bg-background rounded-md px-2 py-1 focus:outline-none focus:ring-2 focus:ring-ring",children:Ye.map(t=>e.jsx("option",{value:t.code,children:t.label},t.code))})]}),e.jsxs("div",{className:"flex items-center justify-between gap-4 min-h-[32px]",children:[e.jsx("span",{className:"text-sm text-foreground/80",children:"质控模式"}),e.jsxs("select",{value:_,onChange:t=>ce(t.target.value),className:"h-8 text-xs border border-input bg-background rounded-md px-2 py-1 focus:outline-none focus:ring-2 focus:ring-ring",children:[e.jsx("option",{value:"standard",children:"标准"}),e.jsx("option",{value:"strict",children:"严格"}),e.jsx("option",{value:"draft",children:"草稿"})]})]})]})]}),e.jsxs("div",{className:"px-4 pt-4 pb-4",children:[e.jsxs("div",{className:"flex items-center justify-between mb-3",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("div",{className:"w-1 h-4 rounded-full bg-primary/40"}),e.jsx("h3",{className:"font-medium text-xs text-muted-foreground",children:"安全护栏"})]}),e.jsxs("span",{className:"relative group",children:[e.jsx(Ie,{size:12,className:"text-muted-foreground cursor-help"}),e.jsx("div",{className:"absolute bottom-full right-0 mb-1.5 w-56 p-2 text-[10px] leading-relaxed bg-popover text-popover-foreground rounded-lg shadow-lg border border-border opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10",children:"医疗文书生成固定经过服务端安全策略；当前接口不允许客户端绕过。"})]})]}),e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("span",{className:"text-xs text-foreground/80 flex items-center gap-1",children:[e.jsx(Xe,{size:12,className:"text-primary"})," 护栏"]}),e.jsx("span",{className:"text-[10px] px-2 py-1 rounded-full bg-emerald-500/10 text-emerald-600",children:"服务端强制"})]}),e.jsx("p",{className:"text-[10px] text-muted-foreground mt-2",children:"请求使用零留存策略；服务端未确认时不会展示生成结果。"})]})]}),we=e.jsx(Ve,{javascript:Ce,python:Se,json:Te}),Ee=e.jsxs("div",{className:"flex flex-col h-full",children:[e.jsx("div",{className:"flex items-center justify-between shrink-0 mb-2",children:e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("div",{className:"flex items-center rounded-lg border border-border p-0.5",children:We.map(t=>e.jsx("button",{onClick:()=>J(t.key),className:`px-2.5 py-1 text-[11px] rounded-md transition-colors ${k===t.key?"bg-primary text-primary-foreground":"text-muted-foreground hover:text-foreground"}`,children:t.label},t.key))}),e.jsx("button",{onClick:ye,disabled:!m,className:"text-xs border border-border rounded px-2 py-1 hover:bg-accent disabled:opacity-30 transition-colors",children:"使用样例"})]})}),e.jsx("textarea",{value:p,onChange:t=>h(t.target.value),maxLength:k==="json"?$:N,placeholder:k==="json"?"输入 context JSON：支持 text、facts 或 transcript...":"输入临床文本、事实摘要或转录文本...",className:"flex-1 w-full resize-none bg-transparent text-sm text-foreground placeholder:text-foreground/70/40 focus:outline-none min-h-0 leading-relaxed"})]}),Ae=e.jsxs("div",{className:"flex flex-col h-full",children:[e.jsxs("div",{className:"flex items-center justify-between shrink-0 mb-2",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[m&&i&&e.jsx("span",{className:"text-xs px-2 py-0.5 rounded bg-primary/10 text-primary",children:i.name}),!m&&e.jsx("span",{className:"text-[11px] text-muted-foreground",children:"请选择模板"})]}),e.jsxs("button",{onClick:fe,disabled:!p.trim()||!m||s,className:"inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-medium bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-30 transition-all shadow-sm shadow-primary/20",children:[s?e.jsx(De,{size:13,className:"animate-spin"}):e.jsx(Q,{size:13}),s?"生成中...":"生成文书"]})]}),e.jsx("div",{className:"flex-1 overflow-y-auto",children:s?e.jsxs("div",{className:"flex flex-col items-center justify-center h-full gap-3 text-muted-foreground",children:[e.jsx("div",{className:"w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin"}),e.jsx("span",{className:"text-sm",children:"生成中..."})]}):y?e.jsx("div",{className:"flex items-center justify-center h-full px-5",children:e.jsx("p",{className:"text-sm text-red-500",children:y})}):f?e.jsxs("div",{className:"p-5",children:[e.jsxs("div",{className:"flex items-center justify-between mb-3",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("div",{className:"w-1 h-4 rounded-full bg-primary/40"}),e.jsx("span",{className:"text-[11px] font-medium text-muted-foreground",children:"生成结果"})]}),e.jsxs("button",{onClick:()=>{navigator.clipboard.writeText(f),q(!0),setTimeout(()=>q(!1),2e3)},className:"text-xs text-muted-foreground hover:text-foreground flex items-center gap-1",children:[V?e.jsx(Me,{size:12}):e.jsx(Oe,{size:12}),V?"已复制":"复制"]})]}),e.jsx("div",{className:"text-sm text-foreground whitespace-pre-wrap leading-relaxed",children:f})]}):e.jsxs("div",{className:"flex flex-col items-center justify-center h-full gap-3 text-muted-foreground/50",children:[e.jsx(Q,{size:28}),e.jsx("p",{className:"text-sm",children:"生成的文书将显示在这里"})]})})]}),Pe=e.jsx(Je,{labels:{settings:"设置",code:"代码"},settings:ke,code:we}),_e=e.jsx(Ue,{events:pe,creditsConsumed:xe});return e.jsxs(e.Fragment,{children:[e.jsx(Be,{title:a.textGenBreadcrumb,description:"基于医疗文书模板快速生成结构化临床文档",inputLabel:"输入",outputLabel:"输出",input:Ee,output:Ae,settings:Pe,eventInspector:_e}),ge&&e.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/40",onClick:()=>b(!1),children:e.jsxs("div",{className:"bg-card rounded-xl border border-border shadow-2xl w-full max-w-lg max-h-[80vh] overflow-hidden",onClick:t=>t.stopPropagation(),children:[e.jsxs("div",{className:"flex items-center justify-between px-5 py-3 border-b border-border",children:[e.jsx("h3",{className:"text-sm font-semibold",children:w?"编辑模板":"新建模板"}),e.jsx("button",{onClick:()=>b(!1),className:"p-1 rounded hover:bg-accent",children:e.jsx(Z,{size:14,className:"text-muted-foreground"})})]}),e.jsxs("div",{className:"px-5 py-4 space-y-4 overflow-y-auto max-h-[60vh]",children:[e.jsxs("div",{className:"grid grid-cols-2 gap-3",children:[e.jsxs("div",{children:[e.jsxs("label",{className:"text-xs font-medium block mb-1",children:["模板键 ",e.jsx("span",{className:"text-red-400",children:"*"})]}),e.jsx("input",{value:E,onChange:t=>I(t.target.value),maxLength:se,placeholder:"discharge_summary",className:"w-full text-xs border border-border rounded-lg px-3 py-2 bg-transparent font-mono"})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"text-xs font-medium block mb-1",children:["名称 ",e.jsx("span",{className:"text-red-400",children:"*"})]}),e.jsx("input",{value:A,onChange:t=>X(t.target.value),maxLength:re,placeholder:"出院小结",className:"w-full text-xs border border-border rounded-lg px-3 py-2 bg-transparent"})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"text-xs font-medium block mb-1",children:"描述"}),e.jsx("input",{value:F,onChange:t=>D(t.target.value),maxLength:ne,placeholder:"简要描述模板用途",className:"w-full text-xs border border-border rounded-lg px-3 py-2 bg-transparent"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"text-xs font-medium block mb-1",children:"分类"}),e.jsx("select",{value:W,onChange:t=>M(t.target.value),className:"w-full text-xs border border-border rounded-lg px-3 py-2 bg-transparent",children:te.filter(t=>t!=="全部").map(t=>e.jsx("option",{value:t,children:t},t))})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"text-xs font-medium block mb-1",children:["样例文本 ",e.jsx("span",{className:"text-muted-foreground font-normal",children:'（点击"使用样例"时填入编辑器的内容）'})]}),e.jsx("textarea",{value:Y,onChange:t=>O(t.target.value),maxLength:ae,placeholder:"输入格式化的示例临床文本...",rows:8,className:"w-full text-xs border border-border rounded-lg px-3 py-2 bg-transparent resize-none focus:outline-none focus:ring-1 focus:ring-ring font-mono"})]})]}),e.jsxs("div",{className:"flex items-center justify-end gap-2 px-5 py-3 border-t border-border bg-muted/30",children:[e.jsx("button",{onClick:()=>b(!1),className:"text-xs px-3 py-1.5 rounded-lg border border-border hover:bg-accent",children:"取消"}),e.jsxs("button",{onClick:Ne,disabled:!E.trim()||!A.trim(),className:"text-xs px-4 py-1.5 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 flex items-center gap-1.5",children:[e.jsx(ee,{size:12})," ",w?"保存":"添加模板"]})]})]})}),ie&&e.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/40",onClick:()=>C(!1),children:e.jsxs("div",{className:"bg-card border border-border rounded-xl shadow-xl w-[480px] max-h-[600px] flex flex-col overflow-hidden",onClick:t=>t.stopPropagation(),children:[e.jsxs("div",{className:"flex items-center justify-between px-5 py-3 border-b border-border",children:[e.jsx("h3",{className:"text-sm font-semibold text-foreground",children:"选择模板"}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs("button",{onClick:t=>{t.stopPropagation(),be(),C(!1)},className:"text-xs px-2 py-1 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 flex items-center gap-1",children:[e.jsx(ee,{size:12})," 新建"]}),e.jsx("button",{onClick:()=>C(!1),className:"p-1 rounded hover:bg-accent",children:e.jsx(Z,{size:16})})]})]}),e.jsxs("div",{className:"p-3 border-b border-border",children:[e.jsx("input",{value:u,onChange:t=>de(t.target.value),maxLength:100,placeholder:"搜索模板...",className:"w-full text-xs border border-border rounded-lg px-3 py-2 bg-card"}),G&&e.jsx("p",{className:"mt-2 text-[10px] text-amber-600",children:G})]}),e.jsx("div",{className:"flex gap-1 px-4 py-2 flex-wrap border-b border-border",children:te.map(t=>e.jsx("button",{onClick:()=>me(t),className:`text-[10px] px-2 py-0.5 rounded-full border transition-colors ${S===t?"bg-primary text-primary-foreground border-primary":"border-border text-muted-foreground hover:bg-accent"}`,children:t},t))}),e.jsx("div",{className:"flex-1 overflow-y-auto py-1",children:c.filter(t=>!(S!=="全部"&&t.category!==S||u&&!t.name.includes(u)&&!t.desc.includes(u))).map(t=>e.jsxs("div",{onClick:()=>{U(t.key),C(!1)},className:`w-full text-left px-5 py-3 hover:bg-accent transition-colors border-b border-border/30 last:border-0 cursor-pointer group ${m===t.key?"bg-primary/5":""}`,children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"text-sm font-medium text-foreground",children:t.name}),e.jsx("span",{className:"text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground",children:t.category}),e.jsx("div",{className:"flex-1"}),he===t.key?e.jsxs("span",{className:"flex items-center gap-1 text-[10px]",onClick:o=>o.stopPropagation(),children:[e.jsx("button",{onClick:()=>ve(t.key),className:"px-1.5 py-0.5 rounded bg-destructive text-destructive-foreground",children:"确认删除"}),e.jsx("button",{onClick:()=>R(null),className:"px-1.5 py-0.5 rounded border border-border",children:"取消"})]}):e.jsxs("span",{className:"flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity",onClick:o=>o.stopPropagation(),children:[e.jsx("button",{onClick:()=>je(t),className:"p-1 rounded hover:bg-accent text-muted-foreground hover:text-foreground transition-colors",title:"编辑模板",children:e.jsx(Re,{size:12})}),e.jsx("button",{onClick:()=>R(t.key),className:"p-1 rounded hover:bg-accent text-muted-foreground hover:text-foreground transition-colors",title:"删除模板",children:e.jsx(ze,{size:12})})]})]}),e.jsx("p",{className:"text-[11px] text-muted-foreground mt-0.5",children:t.desc})]},t.key))})]})})]})}export{N as MAX_GUIDED_CONTEXT_CHARS,$ as MAX_GUIDED_JSON_BYTES,et as default,Fe as parseGuidedDocumentContext,Ke as parseStoredTemplates};
