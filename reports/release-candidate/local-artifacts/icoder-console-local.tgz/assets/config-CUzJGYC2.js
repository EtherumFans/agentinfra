const t={},_=typeof import.meta<"u"&&t?.VITE_BACKEND_URL||"http://localhost:8000";export{_ as B};
