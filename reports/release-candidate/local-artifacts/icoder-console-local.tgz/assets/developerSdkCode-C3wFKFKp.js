const i=[{key:"facts-extract",method:"POST",path:"/api/v2/tools/extract-facts",label:"POST /api/v2/tools/extract-facts",sampleBody:JSON.stringify({context:[{type:"text",text:"患者因腰痛伴左下肢放射痛3月就诊。查体：腰椎活动受限，左下肢直腿抬高试验阳性。"}],outputLanguage:"zh-CN"},null,2)},{key:"agents-run",method:"POST",path:"/api/icoder/agents/note-completeness-agent/v1/message:send",label:"POST /api/icoder/agents/{id}/v1/message:send (A2A)",headers:{"A2A-Protocol-Version":"0.3"},sampleBody:JSON.stringify({jsonrpc:"2.0",id:"q-1",method:"message/send",params:{message:{role:"user",parts:[{kind:"text",text:"请检查以下去标识病历的完整性。"}]}}},null,2)},{key:"coding",method:"POST",path:"/api/v1/coding/predict",label:"POST /api/v1/coding/predict",sampleBody:JSON.stringify({text:"主诉：腹痛3天。",mode:"corti_like_fast",coding_systems:["icd10cn","icd9cm3"],include_evidence:!0,include_trace:!0,filter:{include:[],exclude:[],expand:!0}},null,2)},{key:"usage",method:"GET",path:"/api/usage/summary",label:"GET /api/usage/summary",sampleBody:null}];function a(e,t,n){return[`ICODER_BASE_URL=${e.replace(/\/$/,"")}`,`ICODER_CLIENT_ID=${t||"<client-id>"}`,`ICODER_CLIENT_SECRET=${n||"<copy-secret-when-created>"}`].join(`
`)}function s(e){const t=JSON.stringify(e.replace(/\/$/,""));return{javascript:`import iCoDer, { iCoDerClient } from "@icoder/sdk";

const baseURL = process.env.ICODER_BASE_URL ?? ${t};
const clientId = process.env.ICODER_CLIENT_ID;
const clientSecret = process.env.ICODER_CLIENT_SECRET;
if (!clientId || !clientSecret) throw new Error("Missing iCoDer client credentials");

const authClient = new iCoDerClient({
  baseURL,
  auth: { accessToken: "" },
});
const token = await authClient.authenticate(clientId, clientSecret);
const icoder = new iCoDer({
  baseURL,
  auth: { accessToken: token.access_token },
});

const facts = await icoder.facts.extract({
  context: [{ type: "text", text: "患者因腰痛伴左下肢放射痛3月就诊。" }],
  outputLanguage: "zh-CN",
});
console.log("Facts:", facts.facts);
console.log("Credits:", facts.usageInfo.creditsConsumed);`,dotnet:`using Icoder.Sdk;

var baseUri = new Uri(
    Environment.GetEnvironmentVariable("ICODER_BASE_URL") ?? ${t});
var clientId = Environment.GetEnvironmentVariable("ICODER_CLIENT_ID")
    ?? throw new InvalidOperationException("Missing ICODER_CLIENT_ID");
var clientSecret = Environment.GetEnvironmentVariable("ICODER_CLIENT_SECRET")
    ?? throw new InvalidOperationException("Missing ICODER_CLIENT_SECRET");

using var authClient = new ICoDerClient(new ICoDerClientOptions { BaseUri = baseUri });
var token = await authClient.AuthenticateClientCredentialsAsync(clientId, clientSecret);
using var icoder = new ICoDerClient(new ICoDerClientOptions
{
    BaseUri = baseUri,
    AccessToken = token.AccessToken,
});

var facts = await icoder.Facts.ExtractAsync(new FactExtractionRequest
{
    Context = [new FactExtractionContext
    {
        Text = "患者因腰痛伴左下肢放射痛3月就诊。",
    }],
    OutputLanguage = "zh-CN",
});
Console.WriteLine($"Facts: {facts.Facts.Count}");
Console.WriteLine($"Credits: {facts.UsageInfo.CreditsConsumed}");`}}function c(e){const t={text:e.text,mode:e.mode,coding_systems:e.codingSystems,include_evidence:!0,include_trace:!0,filter:{include:e.includeCodes??[],exclude:e.excludeCodes??[],expand:e.expand??!0}};return{javascript:`import iCoDer from "@icoder/sdk";

const icoder = new iCoDer({
  baseURL: ${JSON.stringify(e.baseURL.replace(/\/$/,""))},
  auth: { accessToken: "<tenant-bound-access-token>" },
});

const result = await icoder.medicalCoding.predict(${JSON.stringify(t,null,2)});
console.log(result.codes, result.cost, result.trace_id);`,json:JSON.stringify({endpoint:"/api/v1/coding/predict",method:"POST",headers:{Authorization:"Bearer <tenant-bound-access-token>","Content-Type":"application/json"},body:t},null,2)}}export{i as D,a,s as b,c};
