# @icoder/sdk

面向中国医院场景的 iCoDer API JavaScript/TypeScript 客户端。当前开发候选版覆盖 Agent Hub、统一 Agent Run、A2A 多轮 Context、事实提取，以及可持久化的 v2 录音与转写生命周期。

## A2A 多轮 Context

```ts
const first = await client.a2a.messageSend('note-completeness-agent', '第一轮');
const second = await client.a2a.messageSend(
  'note-completeness-agent',
  '继续上一轮',
  { contextId: first.contextId },
);
const history = await client.a2a.getContext(
  'note-completeness-agent',
  second.contextId,
);
await client.a2a.deleteContext(history.id);
```

## 安装

发布到 npm registry 前，请从仓库构建并通过本地路径消费：

```bash
cd packages/icoder-sdk
npm install
npm run build
```

## 快速开始

```ts
import iCoDer from '@icoder/sdk';

const client = new iCoDer({
  baseURL: 'https://api.example.cn',
  auth: { accessToken: '<tenant-bound-access-token>' },
});

const hub = await client.agents.hub();
const run = await client.runs.runText(
  'medical-coding-agent',
  '患者因胸痛入院……',
  { idempotencyKey: 'encounter-001' },
);
console.log(hub.total, run.data.trace_id);

const status = await client.runs.get(run.data.run_id);
const cancellation = await client.runs.cancel(run.data.run_id, 'operator request');
const traceToken = new URL(run.data.trace_url).searchParams.get('token');
const events = await client.runs.streamEvents(run.data.run_id, traceToken!);
```

For long-running consumers, prefer the bounded resilient iterator. It resumes
from the last SSE ID, renews an expired signed trace token through the bearer
identity, and never retries 400/403/404/409 or malformed protocol data:

```ts
for await (const event of client.runs.streamEventsResilient(
  run.data.run_id,
  traceToken!,
  { maxAttempts: 4, initialDelayMs: 250, maxDelayMs: 4000 },
)) {
  console.log(event.id, event.event);
}
```

When the server has already purged the retained trace, both stream methods
throw `RunEventRetentionError` (`SSE_TRACE_EXPIRED` or
`SSE_CURSOR_EXPIRED`). The exception exposes only the safe error code and
`retentionDays`; it is terminal and is never retried automatically.

取消结果必须读取 `cancellation.data.outcome`：`RECORDED_ONLY` 表示请求已审计但 Provider
仍在运行，SDK 不会把它误报为已取消。`events` 是签名、去 PHI 的 SSE 生命周期流。
断线后将最后收到的 SSE `id:` 作为第四个 `lastEventId` 参数再次调用
`streamEvents(runId, traceToken, signal, lastEventId)`，服务端会从下一条 trace 恢复。

## Medical Coding 过滤

```ts
const coding = await client.medicalCoding.predict({
  text: '患者有2型糖尿病史。',
  coding_systems: ['icd10cn', 'icd9cm3'],
  filter: { include: ['E11'], exclude: ['E11.0'], expand: true },
});
console.log(coding.codes);
```

中国编码入口支持单独或同时请求 `icd10cn` 诊断和 `icd9cm3` 手术操作。`expand` 开启时
类别按前缀匹配叶子编码，关闭时只匹配完整编码；服务端会在模型返回后再次强制过滤。

开发环境可使用 `http://127.0.0.1:8000`。生产环境应使用 HTTPS，并使用绑定组织租户的短期访问令牌。

## v2 录音与转写

```ts
const recording = await client.speechToText.uploadRecording(
  'interaction-001',
  new TextEncoder().encode('synthetic-audio-for-development'),
  'audio/wav',
);
const transcript = await client.speechToText.createTranscript('interaction-001', {
  recordingId: recording.recordingId,
  primaryLanguage: 'zh-CN',
  async: true,
});
console.log(transcript.statusCode, transcript.location);
```

SDK 在上传前执行 150 MB 客户端限制；服务端仍是最终的鉴权、租户隔离和大小校验边界。

## 实时语音转写

```ts
const socket = await client.speechToText.createSession({ language: 'zh-CN' });
socket.send(audioChunk); // WebM/Opus binary chunk
socket.send(JSON.stringify({ type: 'interim' }));
socket.send(JSON.stringify({ type: 'end' }));
```

`createSession()` 只有在服务端完成 tenant token 鉴权并返回 `ready` 后才成功；连接错误、
提前关闭、无效 setup event 或 5 秒超时均失败关闭。当前验证范围仅含中文、自动标点和
WebM/Opus start，32 MiB 会话总量仍由服务端强制。

## Documents 与 Templates

```ts
const sections = await client.templates.listSections({
  lang: ['zh-CN'],
  region: ['CHN'],
});

const preview = await client.documents.preview(crypto.randomUUID(), {
  context: [{ type: 'string', data: '去标识临床样例文本' }],
  template: {
    sections: sections.slice(0, 2).map(section => ({
      key: section.id,
      nameOverride: section.name,
    })),
  },
  outputLanguage: 'zh-CN',
  documentationMode: 'global_sequential',
});
console.log(preview.sections, preview.usageInfo.creditsConsumed);
```

`documents.preview()` 强制发送 `X-Corti-Retention-Policy: none`，且仅在服务端返回 `acknowledged` 时返回文档。生成内容必须由临床人员复核。

## Facts 与 Text Generation 兼容入口

```ts
const facts = await client.facts.extract({
  context: [{ type: 'text', text: '患者主诉胸痛。' }],
  outputLanguage: 'zh-CN',
});

const generated = await client.textGen.generate('去标识临床文本', {
  template: '出院小结',
  outputLanguage: 'zh-CN',
});
console.log(facts.usageInfo.creditsConsumed, generated.credits_consumed);
```

`textGen.generate()` 是旧调用面的兼容 facade，实际使用 Guided Documents `dynamicTemplate`。它强制生成文书零留存确认；动态模板与 Section 元数据仍会登记在当前租户，因此模板名称不得包含患者标识。`docName`、`maxTokens` 和 `temperature` 当前不受 Guided 合同支持，会在发送前失败关闭。新集成应优先直接使用 Guided Documents 类型。

## 主要资源

| 属性 | 能力 |
| --- | --- |
| `client.agents` | Agent 管理、Hub 卡片和流式调用 |
| `client.runs` | 统一 Agent Run 与 trace 元数据 |
| `client.speechToText` | v2 录音/转写生命周期与鉴权实时 WebSocket |
| `client.documents` | Classic 文档生成、零保留预览及加密生命周期 |
| `client.templates` | Guided Template/Section 发现及租户 Section 管理 |
| `client.facts` | 临床事实提取 |
| `client.textGen` | Guided Documents 动态模板兼容生成（文书零留存） |
| `client.medicalCoding` | 中国医学编码预测、Corti 风格代码过滤与预估费用 |
| `client.reviews` | 医学编码审核 |
| `client.billing` / `client.usage` | 计费和用量查询 |
| `client.oauth` | OAuth 客户端管理接口 |

## 当前发布状态

`1.0.0-beta.6` 是开发发布候选版，尚未发布到 npm registry，也不代表临床上线批准。真实服务冒烟测试见 `examples/real-api-smoke.mjs`；仓库统一脚本验证 Agent Hub、双编码系统 Medical Coding、Agent Run 失败闭合、A2A Context send/continue/get/delete、trace、STT 录音生命周期与实时 `start→ready→close`。

发布准备清单见 [PUBLISH.md](./PUBLISH.md)，版本历史见 [CHANGELOG.md](./CHANGELOG.md)。

## License

MIT
