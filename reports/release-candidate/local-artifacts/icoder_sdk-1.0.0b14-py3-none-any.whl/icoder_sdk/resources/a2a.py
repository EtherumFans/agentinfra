"""A2A v0.3 message and persistent Context resources."""

from __future__ import annotations

from typing import Any, Optional, Union
from urllib.parse import quote
from uuid import uuid4

from ..client import iCoDerClient


class A2AProtocolError(RuntimeError):
    """Protocol error that deliberately does not retain response details/body."""

    def __init__(
        self,
        jsonrpc_code: int,
        a2a_error_code: Optional[str] = None,
        http_status: Optional[int] = None,
    ) -> None:
        label = a2a_error_code or str(jsonrpc_code)
        super().__init__(f"iCoDer A2A request failed ({label})")
        self.jsonrpc_code = jsonrpc_code
        self.a2a_error_code = a2a_error_code
        self.http_status = http_status


class A2ATransportError(RuntimeError):
    """HTTP error that deliberately does not retain request/response objects."""

    def __init__(self, http_status: Optional[int] = None) -> None:
        suffix = f" (HTTP {http_status})" if http_status else ""
        super().__init__(f"iCoDer A2A transport failed{suffix}")
        self.http_status = http_status


def _raise_transport_error(status_code: int) -> None:
    if status_code < 200 or status_code >= 300:
        raise A2ATransportError(status_code)


def _raise_protocol_error(payload: Any, status_code: int) -> None:
    if not isinstance(payload, dict) or not isinstance(payload.get("error"), dict):
        return
    error = payload["error"]
    code = error.get("code")
    if not isinstance(code, int):
        return
    data = error.get("data") if isinstance(error.get("data"), dict) else {}
    business_code = data.get("a2a_error_code")
    raise A2AProtocolError(
        code,
        business_code if isinstance(business_code, str) else None,
        status_code,
    )


class A2AResource:
    def __init__(self, client: iCoDerClient):
        self._client = client

    def message_send(
        self,
        agent_id: str,
        parts: Union[str, list[dict[str, Any]]],
        *,
        context_id: Optional[str] = None,
        message_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        normalized_parts = (
            [{"kind": "text", "text": parts}] if isinstance(parts, str) else parts
        )
        message: dict[str, Any] = {
            "role": "user",
            "parts": normalized_parts,
            "messageId": message_id or f"msg-{uuid4()}",
        }
        if context_id:
            message["contextId"] = context_id
        if metadata:
            message["metadata"] = metadata
        response = self._client.post(
            f"/api/icoder/agents/{quote(agent_id, safe='')}/v1/message:send",
            headers={"A2A-Protocol-Version": "0.3"},
            json={
                "jsonrpc": "2.0",
                "id": f"rpc-{uuid4()}",
                "method": "message/send",
                "params": {"message": message},
            },
        )
        try:
            payload = response.json()
        except ValueError:
            _raise_transport_error(response.status_code)
            raise RuntimeError("iCoDer returned a non-JSON A2A response")
        _raise_protocol_error(payload, response.status_code)
        _raise_transport_error(response.status_code)
        result = payload.get("result") if isinstance(payload, dict) else None
        if not isinstance(result, dict):
            raise RuntimeError("iCoDer returned an incomplete A2A response")
        return result

    def message_stream(
        self,
        agent_id: str,
        parts: Union[str, list[dict[str, Any]]],
        *,
        context_id: Optional[str] = None,
        message_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ):
        """Yield raw SSE ``data`` payloads from authenticated A2A streaming."""
        normalized_parts = (
            [{"kind": "text", "text": parts}] if isinstance(parts, str) else parts
        )
        message: dict[str, Any] = {
            "role": "user",
            "parts": normalized_parts,
            "messageId": message_id or f"msg-{uuid4()}",
        }
        if context_id:
            message["contextId"] = context_id
        if metadata:
            message["metadata"] = metadata
        body = {
            "jsonrpc": "2.0",
            "id": f"rpc-{uuid4()}",
            "method": "message/stream",
            "params": {"message": message},
        }
        path = (
            f"/api/icoder/agents/{quote(agent_id, safe='')}/v1/message:stream"
        )
        for attempt in range(2):
            with self._client.http.stream(
                "POST",
                path,
                headers={
                    "A2A-Protocol-Version": "0.3",
                    "Accept": "text/event-stream",
                },
                json=body,
                timeout=self._client.config.timeout,
            ) as response:
                if (
                    response.status_code == 401
                    and attempt == 0
                    and self._client._refresh_token()
                ):
                    continue
                _raise_transport_error(response.status_code)
                content_type = response.headers.get("content-type", "")
                if not content_type.startswith("text/event-stream"):
                    raise A2ATransportError(response.status_code)
                for line in response.iter_lines():
                    if line.startswith("data:"):
                        yield line[5:].lstrip()
                return

    def get_context(
        self,
        agent_id: str,
        context_id: str,
        *,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        response = self._client.get(
            f"/api/icoder/agents/{quote(agent_id, safe='')}/v1/contexts/"
            f"{quote(context_id, safe='')}",
            headers={"A2A-Protocol-Version": "0.3"},
            params={"limit": limit, "offset": offset},
        )
        try:
            payload = response.json()
        except ValueError:
            _raise_transport_error(response.status_code)
            raise RuntimeError("iCoDer returned a non-JSON Context response")
        _raise_protocol_error(payload, response.status_code)
        _raise_transport_error(response.status_code)
        if not isinstance(payload, dict):
            raise RuntimeError("iCoDer returned an incomplete Context response")
        return payload

    def delete_context(self, context_id: str) -> dict[str, Any]:
        response = self._client.delete(
            f"/api/icoder/contexts/{quote(context_id, safe='')}",
            headers={"A2A-Protocol-Version": "0.3"},
        )
        try:
            payload = response.json()
        except ValueError:
            _raise_transport_error(response.status_code)
            raise RuntimeError("iCoDer returned a non-JSON A2A delete response")
        _raise_protocol_error(payload, response.status_code)
        _raise_transport_error(response.status_code)
        result = payload.get("result") if isinstance(payload, dict) else None
        if not isinstance(result, dict):
            raise RuntimeError("iCoDer returned an incomplete A2A delete response")
        return result
