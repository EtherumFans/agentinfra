"""Agents & Experts resources."""

from __future__ import annotations
from typing import Optional
from urllib.parse import quote

from ..client import iCoDerClient


class AgentsResource:
    def __init__(self, client: iCoDerClient):
        self._client = client

    def list(self, category: str = "", search: str = "") -> dict:
        resp = self._client.get(
            "/api/rest/v1/agent_definitions",
            params={"category": category, "search": search},
        )
        resp.raise_for_status()
        return resp.json()

    def get(self, agent_id: str) -> dict:
        resp = self._client.get(
            f"/api/rest/v1/agent_definitions/{quote(agent_id, safe='')}"
        )
        resp.raise_for_status()
        return resp.json()

    def hub(self, use_case: str = "") -> dict:
        """List Corti-style prebuilt Agent Hub cards and typed contracts."""
        resp = self._client.get(
            "/api/icoder/agents/hub",
            params={"use_case": use_case} if use_case else None,
        )
        resp.raise_for_status()
        return resp.json()

    def card(self, agent_id: str) -> dict:
        """Get one runtime Agent Card by URL-safe Agent id."""
        resp = self._client.get(
            f"/api/icoder/agents/{quote(agent_id, safe='')}/card"
        )
        resp.raise_for_status()
        return resp.json()

    def create(self, name: str, description: str = "", category: str = "",
               system_prompt: str = "", expert_ids: Optional[list[str]] = None) -> dict:
        resp = self._client.post("/api/rest/v1/agent_definitions", json={
            "name": name, "description": description, "category": category,
            "system_prompt": system_prompt, "expert_ids": expert_ids or [],
        })
        resp.raise_for_status()
        return resp.json()

    def update(self, agent_id: str, **kwargs) -> dict:
        resp = self._client.put(
            f"/api/rest/v1/agent_definitions/{quote(agent_id, safe='')}",
            json=kwargs,
        )
        resp.raise_for_status()
        return resp.json()

    def delete(self, agent_id: str) -> None:
        resp = self._client.delete(
            f"/api/rest/v1/agent_definitions/{quote(agent_id, safe='')}"
        )
        resp.raise_for_status()

    def run(self, agent_id: str, input_text: str) -> dict:
        return self._client.a2a.message_send(agent_id, input_text)

    def stream(self, agent_id: str, input_text: str):
        """Stream authenticated A2A SSE payloads from the runtime Agent."""
        yield from self._client.a2a.message_stream(agent_id, input_text)

    def templates(self) -> dict:
        resp = self._client.get("/api/rest/v1/agent_definitions/templates")
        resp.raise_for_status()
        return resp.json()


class ExpertsResource:
    def __init__(self, client: iCoDerClient):
        self._client = client

    def list(self, category: str = "", search: str = "") -> dict:
        resp = self._client.get("/api/experts", params={"category": category, "search": search})
        resp.raise_for_status()
        return resp.json()

    def call(self, name: str, input_text: str) -> dict:
        from urllib.parse import quote
        resp = self._client.post(
            f"/api/experts/call/{quote(name)}?input={quote(input_text)}"
        )
        resp.raise_for_status()
        return resp.json()

    def create(self, name: str, category: str, description: str = "") -> dict:
        resp = self._client.post("/api/experts", json={
            "name": name, "category": category, "description": description,
        })
        resp.raise_for_status()
        return resp.json()

    def delete(self, expert_id: str) -> None:
        resp = self._client.delete(f"/api/experts/{expert_id}")
        resp.raise_for_status()
