"""Declarative Environments/Regions and Tenant compatibility resources."""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from ..client import iCoDerClient


class PlatformResource:
    def __init__(self, client: iCoDerClient):
        self._client = client

    def list_environments(self) -> dict[str, Any]:
        response = self._client.get("/api/platform/environments")
        response.raise_for_status()
        return response.json()

    def list_regions(self) -> dict[str, Any]:
        response = self._client.get("/api/platform/regions")
        response.raise_for_status()
        return response.json()

    def plan_environment(
        self,
        environment_code: str,
        region_code: str,
        *,
        tenant_id: str | None = None,
    ) -> dict[str, Any]:
        response = self._client.post(
            "/api/platform/environments",
            json={
                "environment_code": environment_code,
                "region_code": region_code,
                "tenant_id": tenant_id,
                "dry_run": True,
            },
        )
        response.raise_for_status()
        return response.json()

    def current_tenant(self) -> dict[str, Any]:
        response = self._client.get("/api/tenants/current")
        response.raise_for_status()
        return response.json()

    def tenant_environments(self, tenant_id: str) -> dict[str, Any]:
        response = self._client.get(
            f"/api/tenants/{quote(tenant_id, safe='')}/environments"
        )
        response.raise_for_status()
        return response.json()
