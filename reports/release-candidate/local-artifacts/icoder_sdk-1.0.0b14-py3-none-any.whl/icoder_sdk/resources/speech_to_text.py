"""Speech To Text resource."""

import asyncio
import json
from typing import Any, Optional
from urllib.parse import quote

from ..client import iCoDerClient
from ..types import HttpResult


class SpeechToTextResource:
    MAX_RECORDING_BYTES = 150 * 1024 * 1024

    def __init__(self, client: iCoDerClient):
        self._client = client

    async def create_session_async(self, language: str = "zh-CN",
                                   punctuation: str = "auto",
                                   interim_results: bool = True):
        """Create a WebSocket STT session (async). Requires websockets library."""
        if not language.lower().startswith("zh"):
            raise ValueError("the verified real-time STT runtime currently supports zh-CN only")
        if punctuation == "spoken":
            raise ValueError("spoken punctuation is not supported by the verified real-time STT runtime")
        token = self._client.config.access_token
        if not token:
            raise ValueError("an access token is required for real-time STT")
        try:
            import websockets
        except ImportError:
            raise ImportError("websockets library required. Install: pip install websockets")

        ws_url = self._client.base_url.replace("http://", "ws://").replace("https://", "wss://")
        ws = None
        try:
            ws = await asyncio.wait_for(
                websockets.connect(
                    f"{ws_url}/ws/speech-to-text?token={quote(token, safe='')}"
                ),
                timeout=5,
            )
            await ws.send(json.dumps({
                "type": "start",
                "mimeType": "audio/webm;codecs=opus",
                "language": language,
            }))
            raw_ready = await asyncio.wait_for(ws.recv(), timeout=5)
            ready = json.loads(raw_ready)
            if not isinstance(ready, dict) or ready.get("type") != "ready":
                raise RuntimeError("server did not acknowledge ready")
            return ws
        except asyncio.CancelledError:
            if ws is not None:
                await ws.close()
            raise
        except Exception:
            if ws is not None:
                try:
                    await ws.close()
                except Exception:
                    pass
            # websockets exceptions can retain the full URI including token.
            raise ConnectionError(
                "unable to establish a ready real-time STT session"
            ) from None

    def punctuate(self, text: str) -> dict:
        """Refine punctuation in transcribed text."""
        resp = self._client.post("/api/experts/stt/punctuate", json={"text": text})
        resp.raise_for_status()
        return resp.json()

    def upload_recording(
        self,
        interaction_id: str,
        audio: bytes,
        media_type: str = "application/octet-stream",
    ) -> dict[str, Any]:
        if not audio:
            raise ValueError("audio cannot be empty")
        if len(audio) > self.MAX_RECORDING_BYTES:
            raise ValueError(f"audio exceeds {self.MAX_RECORDING_BYTES} bytes")
        normalized_media_type = media_type.split(";", 1)[0].strip().lower()
        supported = {
            "application/octet-stream", "audio/wav", "audio/x-wav",
            "audio/webm", "audio/mpeg", "audio/mp4", "audio/ogg",
        }
        if normalized_media_type not in supported:
            raise ValueError(f"unsupported recording media type: {normalized_media_type or '<empty>'}")
        response = self._client.post(
            f"/api/v2/tools/interactions/{quote(interaction_id, safe='')}/recordings",
            content=audio,
            headers={"Content-Type": media_type},
        )
        response.raise_for_status()
        return response.json()

    def list_recordings(self, interaction_id: str) -> dict[str, Any]:
        response = self._client.get(
            f"/api/v2/tools/interactions/{quote(interaction_id, safe='')}/recordings"
        )
        response.raise_for_status()
        return response.json()

    def download_recording(self, interaction_id: str, recording_id: str) -> bytes:
        response = self._client.get(
            f"/api/v2/tools/interactions/{quote(interaction_id, safe='')}/recordings/"
            f"{quote(recording_id, safe='')}"
        )
        response.raise_for_status()
        return response.content

    def delete_recording(self, interaction_id: str, recording_id: str) -> None:
        response = self._client.delete(
            f"/api/v2/tools/interactions/{quote(interaction_id, safe='')}/recordings/"
            f"{quote(recording_id, safe='')}"
        )
        response.raise_for_status()

    def create_transcript(
        self,
        interaction_id: str,
        recording_id: str,
        *,
        primary_language: str = "zh-CN",
        async_: bool = False,
        participants: Optional[list[dict[str, Any]]] = None,
        replacements: Optional[list[dict[str, str]]] = None,
    ) -> HttpResult[dict[str, Any]]:
        if not primary_language.lower().startswith("zh"):
            raise ValueError("the verified STT runtime currently supports Chinese audio only")
        if participants and len(participants) > 1:
            raise ValueError("the verified STT runtime supports at most one participant mapping")
        if replacements and len(replacements) > 1000:
            raise ValueError("replacements cannot exceed 1000 items")
        response = self._client.post(
            f"/api/v2/tools/interactions/{quote(interaction_id, safe='')}/transcripts",
            json={
                "recordingId": recording_id,
                "primaryLanguage": primary_language,
                "async": async_,
                "participants": participants,
                "replacements": replacements,
            },
        )
        response.raise_for_status()
        return HttpResult(
            data=response.json(),
            status_code=response.status_code,
            location=response.headers.get("Location"),
        )

    def list_transcripts(self, interaction_id: str, *, full: bool = False) -> dict[str, Any]:
        response = self._client.get(
            f"/api/v2/tools/interactions/{quote(interaction_id, safe='')}/transcripts",
            params={"full": str(full).lower()},
        )
        response.raise_for_status()
        return response.json()

    def get_transcript(self, interaction_id: str, transcript_id: str) -> dict[str, Any]:
        response = self._client.get(
            f"/api/v2/tools/interactions/{quote(interaction_id, safe='')}/transcripts/"
            f"{quote(transcript_id, safe='')}"
        )
        response.raise_for_status()
        return response.json()

    def get_transcript_status(self, interaction_id: str, transcript_id: str) -> dict[str, Any]:
        response = self._client.get(
            f"/api/v2/tools/interactions/{quote(interaction_id, safe='')}/transcripts/"
            f"{quote(transcript_id, safe='')}/status"
        )
        response.raise_for_status()
        return response.json()

    def delete_transcript(self, interaction_id: str, transcript_id: str) -> None:
        response = self._client.delete(
            f"/api/v2/tools/interactions/{quote(interaction_id, safe='')}/transcripts/"
            f"{quote(transcript_id, safe='')}"
        )
        response.raise_for_status()
