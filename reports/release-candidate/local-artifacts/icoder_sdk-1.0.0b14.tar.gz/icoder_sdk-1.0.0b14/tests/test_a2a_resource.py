import json

import httpx
import pytest

from icoder_sdk import (
    A2AProtocolError,
    A2ATransportError,
    iCoDerClient,
    iCoDerConfig,
)


def _client(handler):
    client = iCoDerClient(
        iCoDerConfig(base_url="https://api.cn.icoder.cloud", access_token="token")
    )
    client.http.close()
    client.http = httpx.Client(
        base_url=client.base_url,
        headers={"Authorization": "Bearer token"},
        transport=httpx.MockTransport(handler),
    )
    return client


def test_a2a_multi_turn_get_and_delete_contract():
    calls = []
    context_id = "11111111-1111-4111-8111-111111111111"

    def handler(request):
        body = json.loads(request.content) if request.content else None
        calls.append((request, body))
        if request.method == "POST":
            return httpx.Response(200, json={
                "jsonrpc": "2.0",
                "id": body["id"],
                "result": {
                    "kind": "message",
                    "role": "agent",
                    "messageId": f"agent-{len(calls)}",
                    "contextId": context_id,
                    "parts": [],
                    "metadata": {},
                },
            })
        if request.method == "GET":
            return httpx.Response(200, json={"id": context_id, "items": [{}, {}, {}, {}]})
        return httpx.Response(200, json={
            "jsonrpc": "2.0",
            "id": None,
            "result": {
                "kind": "context",
                "contextId": context_id,
                "deleted": True,
                "reason": "user_requested",
            },
        })

    client = _client(handler)
    try:
        first = client.a2a.message_send("note-completeness-agent", "first")
        second = client.a2a.message_send(
            "note-completeness-agent", "second", context_id=first["contextId"]
        )
        context = client.a2a.get_context("note-completeness-agent", context_id)
        deleted = client.a2a.delete_context(context_id)
    finally:
        client.close()

    assert second["contextId"] == context_id
    assert len(context["items"]) == 4
    assert deleted["deleted"] is True
    assert all(request.headers["A2A-Protocol-Version"] == "0.3" for request, _ in calls)
    assert calls[1][1]["params"]["message"]["contextId"] == context_id


def test_a2a_protocol_error_does_not_retain_details():
    def handler(_request):
        return httpx.Response(500, json={
            "jsonrpc": "2.0",
            "id": "rpc-1",
            "error": {
                "code": -32603,
                "message": "Internal error",
                "data": {
                    "a2a_error_code": "PLANNING_FAILED",
                    "details": "patient-secret-value",
                },
            },
        })

    client = _client(handler)
    try:
        with pytest.raises(A2AProtocolError) as raised:
            client.a2a.message_send("note-completeness-agent", "synthetic")
    finally:
        client.close()

    assert raised.value.jsonrpc_code == -32603
    assert raised.value.a2a_error_code == "PLANNING_FAILED"
    assert "patient-secret-value" not in str(raised.value)


def test_a2a_transport_error_does_not_retain_request_or_body():
    def handler(_request):
        return httpx.Response(500, json={"detail": "patient-secret-value"})

    client = _client(handler)
    try:
        with pytest.raises(A2ATransportError) as raised:
            client.a2a.message_send("note-completeness-agent", "synthetic")
    finally:
        client.close()

    assert raised.value.http_status == 500
    assert "patient-secret-value" not in str(raised.value)
    assert not hasattr(raised.value, "request")
    assert not hasattr(raised.value, "response")
